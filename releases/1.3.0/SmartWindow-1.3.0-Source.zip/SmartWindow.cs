using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Media;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using Microsoft.Win32;

namespace SmartWindow
{
    internal sealed class NotificationItem
    {
        public string AppName;
        public string Title;
        public string Body;
        public DateTime ArrivedAt;
        public long CursorOrder;
        public bool IsMedia;
        public bool IsSizePreview;
        public string ArtworkPath;
        public string MediaSignature;
    }

    internal sealed class NotificationHistoryEntry
    {
        public DateTime ReceivedAt;
        public string AppName;
        public string Title;
        public string Body;
        public bool WasFiltered;
        public bool WasSuppressed;
    }

    internal sealed class FullscreenDetector
    {
        private const int QunsBusy = 2;
        private const int QunsD3DFullScreen = 3;
        private const int QunsPresentationMode = 4;

        public bool IsSuppressed()
        {
            int state;
            if (SHQueryUserNotificationState(out state) == 0 &&
                (state == QunsBusy ||
                 state == QunsD3DFullScreen ||
                 state == QunsPresentationMode))
            {
                return true;
            }

            IntPtr foreground = GetForegroundWindow();
            if (foreground == IntPtr.Zero)
            {
                return false;
            }
            string className = WindowClassName(foreground);
            if (className == "Progman" ||
                className == "WorkerW" ||
                className == "Shell_TrayWnd" ||
                className == "MultitaskingViewFrame")
            {
                return false;
            }

            NativeRect windowRect;
            if (!GetWindowRect(foreground, out windowRect) ||
                windowRect.Right <= windowRect.Left ||
                windowRect.Bottom <= windowRect.Top)
            {
                return false;
            }
            IntPtr monitor = MonitorFromWindow(
                foreground,
                2);
            MonitorInfo monitorInfo = new MonitorInfo();
            monitorInfo.Size = Marshal.SizeOf(monitorInfo);
            if (!GetMonitorInfo(monitor, ref monitorInfo))
            {
                return false;
            }
            NativeRect monitorRect = monitorInfo.Monitor;
            int width = monitorRect.Right - monitorRect.Left;
            int height = monitorRect.Bottom - monitorRect.Top;
            int windowWidth = windowRect.Right - windowRect.Left;
            int windowHeight = windowRect.Bottom - windowRect.Top;
            return windowRect.Left <= monitorRect.Left + 2 &&
                windowRect.Top <= monitorRect.Top + 2 &&
                windowRect.Right >= monitorRect.Right - 2 &&
                windowRect.Bottom >= monitorRect.Bottom - 2 &&
                windowWidth >= width * 0.96 &&
                windowHeight >= height * 0.96;
        }

        private static string WindowClassName(IntPtr window)
        {
            StringBuilder builder = new StringBuilder(256);
            GetClassName(window, builder, builder.Capacity);
            return builder.ToString();
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct NativeRect
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct MonitorInfo
        {
            public int Size;
            public NativeRect Monitor;
            public NativeRect Work;
            public uint Flags;
        }

        [DllImport("shell32.dll")]
        private static extern int SHQueryUserNotificationState(
            out int state);

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        private static extern bool GetWindowRect(
            IntPtr window,
            out NativeRect rectangle);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern int GetClassName(
            IntPtr window,
            StringBuilder className,
            int maximumCount);

        [DllImport("user32.dll")]
        private static extern IntPtr MonitorFromWindow(
            IntPtr window,
            uint flags);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern bool GetMonitorInfo(
            IntPtr monitor,
            ref MonitorInfo info);
    }

    internal static class Program
    {
        [STAThread]
        private static void Main(string[] args)
        {
            bool restoreOnly = HasArgument(args, "--restore");
            bool muteBanners = !HasArgument(args, "--no-mute");
            bool showConsole = !HasArgument(args, "--background");
            WindowsCompatibility.Initialize();

            if (!DonationIntegrityGuard.EnforceOrShutdown())
            {
                return;
            }

            if (!WindowsCompatibility.IsSupported)
            {
                MessageBox.Show(
                    "智慧窗需要 " +
                    WindowsCompatibility.MinimumRequirementText +
                    "。\r\n\r\n当前系统：" +
                    WindowsCompatibility.DisplayName,
                    "智慧窗",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            bool firstInstance;
            using (Mutex instanceMutex = new Mutex(
                true,
                "Local\\SmartWindow.SingleInstance",
                out firstInstance))
            {
                if (!firstInstance)
                {
                    try
                    {
                        using (EventWaitHandle showEvent =
                            EventWaitHandle.OpenExisting(
                                "Local\\SmartWindow.ShowConsole"))
                        {
                            showEvent.Set();
                        }
                    }
                    catch
                    {
                    }
                    return;
                }

                BannerMuter muter = new BannerMuter();
                try
                {
                    RuntimeAssets.Initialize();
                    Logger.Write(
                        "Running on " +
                        WindowsCompatibility.DisplayName +
                        " (Windows 10 compatibility=" +
                        (WindowsCompatibility.IsWindows10 ? "true" : "false") +
                        ").");
                    // A previous forced shutdown can leave banner settings muted.
                    muter.RestoreBackup();
                    if (restoreOnly)
                    {
                        return;
                    }

                    if (muteBanners)
                    {
                        muter.MuteCurrentApps();
                    }

                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    Application.SetUnhandledExceptionMode(
                        UnhandledExceptionMode.CatchException);
                    Application.ThreadException += delegate(
                        object sender,
                        System.Threading.ThreadExceptionEventArgs eventArgs)
                    {
                        Logger.Write(
                            "Unhandled UI exception: " +
                            eventArgs.Exception);
                    };
                    AppDomain.CurrentDomain.UnhandledException += delegate(
                        object sender,
                        UnhandledExceptionEventArgs eventArgs)
                    {
                        Logger.Write(
                            "Unhandled process exception: " +
                            eventArgs.ExceptionObject);
                    };
                    using (IslandApplication application =
                        new IslandApplication(
                            muter,
                            muteBanners,
                            showConsole))
                    {
                        Application.Run(application);
                    }
                }
                catch (Exception exception)
                {
                    Logger.Write(exception.ToString());
                    CrashGuard.RegisterCrash();
                    muter.RestoreBackup();
                    if (!restoreOnly)
                    {
                        MessageBox.Show(
                            "智慧窗启动失败。\r\n\r\n" + exception.Message +
                            "\r\n\r\n日志：" + Logger.LogPath,
                            "智慧窗",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }
                }
                finally
                {
                    muter.Dispose();
                    instanceMutex.ReleaseMutex();
                }
            }
        }

        private static bool HasArgument(string[] args, string expected)
        {
            for (int index = 0; index < args.Length; index++)
            {
                if (string.Equals(
                    args[index],
                    expected,
                    StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }
    }

    internal static class Logger
    {
        private static readonly string DataDirectory = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "SmartWindow");
        private static readonly object Sync = new object();

        public static readonly string LogPath = Path.Combine(
            DataDirectory,
            "SmartWindow.log");

        public static void Write(string message)
        {
            lock (Sync)
            {
                try
                {
                    Directory.CreateDirectory(DataDirectory);
                    FileInfo current = new FileInfo(LogPath);
                    if (current.Exists && current.Length > 5 * 1024 * 1024)
                    {
                        string archive = LogPath + ".1";
                        if (File.Exists(archive))
                        {
                            File.Delete(archive);
                        }
                        File.Move(LogPath, archive);
                    }
                    File.AppendAllText(
                        LogPath,
                        DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") +
                        " " +
                        message +
                        Environment.NewLine,
                        Encoding.UTF8);
                }
                catch
                {
                    // Logging must never prevent the overlay from shutting down.
                }
            }
        }
    }

    internal static class CrashGuard
    {
        private static readonly string DirectoryPath = Path.Combine(
            Environment.GetFolderPath(
                Environment.SpecialFolder.LocalApplicationData),
            "SmartWindow");
        private static readonly string CountPath = Path.Combine(
            DirectoryPath,
            "crash-count.dat");
        private static readonly string SafeModePath = Path.Combine(
            DirectoryPath,
            "safe-mode.flag");

        public static bool IsSafeMode()
        {
            return File.Exists(SafeModePath);
        }

        public static void RegisterCrash()
        {
            try
            {
                Directory.CreateDirectory(DirectoryPath);
                int count = 0;
                if (File.Exists(CountPath))
                {
                    int.TryParse(File.ReadAllText(CountPath), out count);
                }
                count++;
                File.WriteAllText(CountPath, count.ToString());
                if (count >= 3)
                {
                    File.WriteAllText(
                        SafeModePath,
                        DateTime.Now.ToString("O"));
                }
            }
            catch
            {
            }
        }

        public static void MarkHealthy()
        {
            try
            {
                if (File.Exists(CountPath))
                {
                    File.Delete(CountPath);
                }
                if (File.Exists(SafeModePath))
                {
                    File.Delete(SafeModePath);
                }
            }
            catch
            {
            }
        }
    }

    internal static class SystemVolume
    {
        public static double Get()
        {
            try
            {
                using (AudioEndpoint endpoint =
                    AudioEndpoint.Create())
                {
                    float value;
                    return endpoint.Volume.GetMasterVolumeLevelScalar(
                        out value) == 0
                        ? Math.Max(0.0, Math.Min(1.0, value))
                        : 0.5;
                }
            }
            catch (Exception exception)
            {
                Logger.Write("SystemVolume.Get: " + exception);
                return 0.5;
            }
        }

        public static void Set(double value)
        {
            try
            {
                using (AudioEndpoint endpoint =
                    AudioEndpoint.Create())
                {
                    Guid context = Guid.Empty;
                    endpoint.Volume.SetMasterVolumeLevelScalar(
                        (float)Math.Max(0.0, Math.Min(1.0, value)),
                        ref context);
                }
            }
            catch (Exception exception)
            {
                Logger.Write("SystemVolume.Set: " + exception);
            }
        }

        [ComImport]
        [Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
        private class MMDeviceEnumeratorComObject
        {
        }

        [ComImport]
        [Guid("A95664D2-9614-4F35-A746-DE8DB63617E6")]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IMMDeviceEnumerator
        {
            [PreserveSig]
            int EnumAudioEndpoints(
                int dataFlow,
                int stateMask,
                out IntPtr devices);
            [PreserveSig]
            int GetDefaultAudioEndpoint(
                int dataFlow,
                int role,
                out IMMDevice endpoint);
            [PreserveSig]
            int GetDevice(string id, out IMMDevice device);
            [PreserveSig]
            int RegisterEndpointNotificationCallback(IntPtr client);
            [PreserveSig]
            int UnregisterEndpointNotificationCallback(IntPtr client);
        }

        [ComImport]
        [Guid("D666063F-1587-4E43-81F1-B948E807363F")]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IMMDevice
        {
            [PreserveSig]
            int Activate(
                ref Guid interfaceId,
                uint classContext,
                IntPtr activationParameters,
                out IntPtr interfacePointer);
            [PreserveSig]
            int OpenPropertyStore(
                uint access,
                out IntPtr properties);
            [PreserveSig]
            int GetId(out IntPtr id);
            [PreserveSig]
            int GetState(out uint state);
        }

        [ComImport]
        [Guid("5CDF2C82-841E-4546-9722-0CF74078229A")]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IAudioEndpointVolume
        {
            [PreserveSig]
            int RegisterControlChangeNotify(IntPtr notify);
            [PreserveSig]
            int UnregisterControlChangeNotify(IntPtr notify);
            [PreserveSig]
            int GetChannelCount(out uint channelCount);
            [PreserveSig]
            int SetMasterVolumeLevel(
                float level,
                ref Guid eventContext);
            [PreserveSig]
            int SetMasterVolumeLevelScalar(
                float level,
                ref Guid eventContext);
            [PreserveSig]
            int GetMasterVolumeLevel(out float level);
            [PreserveSig]
            int GetMasterVolumeLevelScalar(out float level);
        }

        private sealed class AudioEndpoint : IDisposable
        {
            public IAudioEndpointVolume Volume;
            private IMMDevice device;

            public static AudioEndpoint Create()
            {
                IMMDeviceEnumerator enumerator =
                    (IMMDeviceEnumerator)
                    (object)new MMDeviceEnumeratorComObject();
                IMMDevice device;
                int result = enumerator.GetDefaultAudioEndpoint(
                    0,
                    1,
                    out device);
                if (result != 0 || device == null)
                {
                    throw new InvalidOperationException(
                        "No default audio endpoint.");
                }
                Guid interfaceId =
                    typeof(IAudioEndpointVolume).GUID;
                IntPtr pointer;
                result = device.Activate(
                    ref interfaceId,
                    23,
                    IntPtr.Zero,
                    out pointer);
                if (result != 0 || pointer == IntPtr.Zero)
                {
                    throw new InvalidOperationException(
                        "Audio endpoint activation failed.");
                }
                AudioEndpoint endpoint = new AudioEndpoint();
                endpoint.device = device;
                endpoint.Volume =
                    (IAudioEndpointVolume)
                    Marshal.GetObjectForIUnknown(pointer);
                Marshal.Release(pointer);
                return endpoint;
            }

            public void Dispose()
            {
                if (Volume != null &&
                    Marshal.IsComObject(Volume))
                {
                    Marshal.ReleaseComObject(Volume);
                    Volume = null;
                }
                if (device != null &&
                    Marshal.IsComObject(device))
                {
                    Marshal.ReleaseComObject(device);
                    device = null;
                }
            }
        }
    }

    internal static class AutoStartManager
    {
        private const string RunKeyPath =
            @"Software\Microsoft\Windows\CurrentVersion\Run";
        private const string ValueName = "SmartWindow";

        public static bool IsEnabled()
        {
            if (PackagedStartupManager.IsSupported)
            {
                return PackagedStartupManager.IsEnabled();
            }
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(
                    RunKeyPath,
                    false))
                {
                    return key != null &&
                        key.GetValue(ValueName) != null;
                }
            }
            catch (Exception exception)
            {
                Logger.Write("AutoStartManager.IsEnabled: " + exception);
                return false;
            }
        }

        public static bool SetEnabled(bool enabled)
        {
            if (PackagedStartupManager.IsSupported)
            {
                return PackagedStartupManager.SetEnabled(enabled);
            }
            try
            {
                using (RegistryKey key = Registry.CurrentUser.CreateSubKey(
                    RunKeyPath))
                {
                    if (key == null)
                    {
                        return false;
                    }
                    if (enabled)
                    {
                        key.SetValue(
                            ValueName,
                            "\"" + Application.ExecutablePath +
                                "\" --background",
                            RegistryValueKind.String);
                    }
                    else
                    {
                        key.DeleteValue(ValueName, false);
                    }
                }
                return true;
            }
            catch (Exception exception)
            {
                Logger.Write("AutoStartManager.SetEnabled: " + exception);
                return false;
            }
        }

        public static void RefreshCommandIfEnabled()
        {
            if (PackagedStartupManager.IsSupported)
            {
                return;
            }
            if (IsEnabled())
            {
                SetEnabled(true);
            }
        }
    }

    internal static class PackagedStartupManager
    {
        private const string TaskId = "SmartWindowStartup";
        private static readonly Type StartupTaskType =
            Type.GetType(
                "Windows.ApplicationModel.StartupTask, " +
                "Windows.ApplicationModel, ContentType=WindowsRuntime");
        private static readonly Type AsyncExtensionsType =
            Type.GetType(
                "System.WindowsRuntimeSystemExtensions, " +
                "System.Runtime.WindowsRuntime");

        public static bool IsSupported
        {
            get
            {
                if (StartupTaskType == null ||
                    AsyncExtensionsType == null)
                {
                    return false;
                }
                uint length = 0;
                int result = GetCurrentPackageFullName(
                    ref length,
                    null);
                return result != 15700;
            }
        }

        public static bool IsEnabled()
        {
            try
            {
                object task = Await(
                    StartupTaskType.GetMethod(
                        "GetAsync",
                        new Type[] { typeof(string) })
                        .Invoke(null, new object[] { TaskId }),
                    StartupTaskType);
                string state = task.GetType()
                    .GetProperty("State")
                    .GetValue(task, null)
                    .ToString();
                return state == "Enabled" ||
                    state == "EnabledByPolicy";
            }
            catch (Exception exception)
            {
                Logger.Write("PackagedStartupManager.IsEnabled: " + exception);
                return false;
            }
        }

        public static bool SetEnabled(bool enabled)
        {
            try
            {
                object current = Await(
                    StartupTaskType.GetMethod(
                        "GetAsync",
                        new Type[] { typeof(string) })
                        .Invoke(null, new object[] { TaskId }),
                    StartupTaskType);
                if (!enabled)
                {
                    current.GetType()
                        .GetMethod("Disable")
                        .Invoke(current, null);
                    return true;
                }

                object result = Await(
                    current.GetType()
                        .GetMethod("RequestEnableAsync")
                        .Invoke(current, null),
                    StartupTaskType);
                string state = result.GetType()
                    .GetProperty("State")
                    .GetValue(result, null)
                    .ToString();
                return state == "Enabled" ||
                    state == "EnabledByPolicy";
            }
            catch (Exception exception)
            {
                Logger.Write("PackagedStartupManager.SetEnabled: " + exception);
                return false;
            }
        }

        private static object Await(object operation, Type resultType)
        {
            MethodInfo asTask = null;
            foreach (MethodInfo method in AsyncExtensionsType.GetMethods())
            {
                if (method.Name != "AsTask" ||
                    !method.IsGenericMethod)
                {
                    continue;
                }
                ParameterInfo[] parameters = method.GetParameters();
                if (parameters.Length == 1 &&
                    parameters[0].ParameterType.Name.StartsWith(
                        "IAsyncOperation",
                        StringComparison.Ordinal))
                {
                    asTask = method;
                    break;
                }
            }
            if (asTask == null)
            {
                throw new MissingMethodException(
                    "WindowsRuntime AsTask method was not found.");
            }
            Task task = (Task)asTask
                .MakeGenericMethod(resultType)
                .Invoke(null, new object[] { operation });
            task.Wait();
            return task.GetType().GetProperty("Result")
                .GetValue(task, null);
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
        private static extern int GetCurrentPackageFullName(
            ref uint packageFullNameLength,
            StringBuilder packageFullName);
    }

    internal sealed class BannerState
    {
        public bool Exists;
        public int Value;
    }

    internal sealed class BannerMuter : IDisposable
    {
        private const string SettingsPath =
            @"Software\Microsoft\Windows\CurrentVersion\Notifications\Settings";

        private const string ValueName = "ShowBanner";

        private readonly object sync = new object();
        private readonly Dictionary<string, BannerState> states =
            new Dictionary<string, BannerState>(StringComparer.OrdinalIgnoreCase);

        private readonly string dataDirectory;
        private readonly string backupPath;
        private bool stopping;
        private bool disposed;

        public BannerMuter()
        {
            dataDirectory = Path.Combine(
                Environment.GetFolderPath(
                    Environment.SpecialFolder.LocalApplicationData),
                "SmartWindow");
            backupPath = Path.Combine(dataDirectory, "banner-backup.dat");
        }

        public void MuteCurrentApps()
        {
            lock (sync)
            {
                if (disposed || stopping)
                {
                    return;
                }

                try
                {
                    Directory.CreateDirectory(dataDirectory);
                    using (RegistryKey settings =
                        Registry.CurrentUser.OpenSubKey(SettingsPath, true))
                    {
                        if (settings == null)
                        {
                            return;
                        }

                        bool changed = false;
                        string[] appNames = settings.GetSubKeyNames();
                        for (int index = 0; index < appNames.Length; index++)
                        {
                            string appName = appNames[index];
                            if (states.ContainsKey(appName))
                            {
                                continue;
                            }

                            using (RegistryKey appKey =
                                settings.OpenSubKey(appName, true))
                            {
                                if (appKey == null)
                                {
                                    continue;
                                }

                                BannerState state = new BannerState();
                                object current = appKey.GetValue(
                                    ValueName,
                                    null,
                                    RegistryValueOptions.DoNotExpandEnvironmentNames);
                                state.Exists = current != null;
                                if (current != null)
                                {
                                    if (!(current is int))
                                    {
                                        continue;
                                    }
                                    state.Value = (int)current;
                                }

                                states[appName] = state;
                                appKey.SetValue(
                                    ValueName,
                                    0,
                                    RegistryValueKind.DWord);
                                changed = true;
                            }
                        }

                        if (changed)
                        {
                            SaveBackup();
                        }
                    }
                }
                catch (Exception exception)
                {
                    Logger.Write("MuteCurrentApps: " + exception);
                }
            }
        }

        public void RestoreBackup()
        {
            lock (sync)
            {
                try
                {
                    if (!File.Exists(backupPath))
                    {
                        return;
                    }

                    states.Clear();
                    LoadBackup();
                    ApplyRestore();
                }
                catch (Exception exception)
                {
                    Logger.Write("RestoreBackup: " + exception);
                }
            }
        }

        public void StopAndRestore()
        {
            lock (sync)
            {
                stopping = true;
                RestoreBackup();
            }
        }

        private void ApplyRestore()
        {
            using (RegistryKey settings =
                Registry.CurrentUser.OpenSubKey(SettingsPath, true))
            {
                if (settings != null)
                {
                    foreach (KeyValuePair<string, BannerState> pair in states)
                    {
                        try
                        {
                            using (RegistryKey appKey =
                                settings.OpenSubKey(pair.Key, true))
                            {
                                if (appKey == null)
                                {
                                    continue;
                                }

                                if (pair.Value.Exists)
                                {
                                    appKey.SetValue(
                                        ValueName,
                                        pair.Value.Value,
                                        RegistryValueKind.DWord);
                                }
                                else
                                {
                                    appKey.DeleteValue(
                                        ValueName,
                                        false);
                                }
                            }
                        }
                        catch (Exception exception)
                        {
                            Logger.Write(
                                "Restore app " + pair.Key + ": " + exception);
                        }
                    }
                }
            }

            states.Clear();
            if (File.Exists(backupPath))
            {
                File.Delete(backupPath);
            }
        }

        private void SaveBackup()
        {
            Directory.CreateDirectory(dataDirectory);
            List<string> lines = new List<string>();
            lines.Add("SMARTWINDOW_BANNER_BACKUP_V1");
            foreach (KeyValuePair<string, BannerState> pair in states)
            {
                string key = Convert.ToBase64String(
                    Encoding.UTF8.GetBytes(pair.Key));
                string value = pair.Value.Exists
                    ? "1:" + pair.Value.Value.ToString(
                        System.Globalization.CultureInfo.InvariantCulture)
                    : "0";
                lines.Add(key + "\t" + value);
            }

            string temporaryPath = backupPath + ".tmp";
            File.WriteAllLines(temporaryPath, lines.ToArray(), Encoding.UTF8);
            if (File.Exists(backupPath))
            {
                File.Delete(backupPath);
            }
            File.Move(temporaryPath, backupPath);
        }

        private void LoadBackup()
        {
            string[] lines = File.ReadAllLines(backupPath, Encoding.UTF8);
            for (int index = 0; index < lines.Length; index++)
            {
                string line = lines[index];
                if (string.IsNullOrWhiteSpace(line) ||
                    line.StartsWith("SMARTWINDOW_", StringComparison.Ordinal))
                {
                    continue;
                }

                string[] parts = line.Split('\t');
                if (parts.Length != 2)
                {
                    continue;
                }

                string appName = Encoding.UTF8.GetString(
                    Convert.FromBase64String(parts[0]));
                BannerState state = new BannerState();
                if (parts[1].StartsWith("1:", StringComparison.Ordinal))
                {
                    state.Exists = true;
                    int value;
                    if (int.TryParse(
                        parts[1].Substring(2),
                        System.Globalization.NumberStyles.Integer,
                        System.Globalization.CultureInfo.InvariantCulture,
                        out value))
                    {
                        state.Value = value;
                    }
                }
                states[appName] = state;
            }
        }

        public void Dispose()
        {
            lock (sync)
            {
                if (disposed)
                {
                    return;
                }

                stopping = true;
                try
                {
                    if (states.Count > 0)
                    {
                        ApplyRestore();
                    }
                }
                catch (Exception exception)
                {
                    Logger.Write("Dispose: " + exception);
                }
                disposed = true;
            }
        }
    }

    internal sealed class NotificationDatabase : IDisposable
    {
        private const int SqliteOk = 0;
        private const int SqliteRow = 100;
        private const int SqliteDone = 101;
        private const int OpenReadOnly = 0x00000001;
        private const int OpenUri = 0x00000040;
        private const int BusyTimeoutMilliseconds = 1800;

        private readonly string databasePath;
        private IntPtr database;
        private bool disposed;

        public NotificationDatabase()
        {
            databasePath = Path.Combine(
                Environment.GetFolderPath(
                    Environment.SpecialFolder.LocalApplicationData),
                "Microsoft",
                "Windows",
                "Notifications",
                "wpndatabase.db");
        }

        public long GetLatestOrder()
        {
            EnsureOpen();
            using (Statement statement = Prepare(
                "select coalesce(max([Order]), 0) from Notification " +
                "where lower([Type]) = 'toast';"))
            {
                if (statement.Step() != SqliteRow)
                {
                    return 0;
                }
                return statement.ColumnInt64(0);
            }
        }

        public List<NotificationItem> GetNewNotifications(long afterOrder)
        {
            EnsureOpen();
            List<NotificationItem> result = new List<NotificationItem>();
            const string sql =
                "select n.[Order], n.Payload, h.PrimaryId " +
                "from Notification n " +
                "left join NotificationHandler h " +
                "on h.RecordId = n.HandlerId " +
                "where lower(n.[Type]) = 'toast' and n.[Order] > ?1 " +
                "order by n.[Order] asc limit 20;";

            using (Statement statement = Prepare(sql))
            {
                statement.BindInt64(1, afterOrder);
                while (true)
                {
                    int step = statement.Step();
                    if (step == SqliteDone)
                    {
                        break;
                    }
                    if (step != SqliteRow)
                    {
                        throw CreateError("读取新通知失败");
                    }

                    byte[] payload = statement.ColumnBytes(1);
                    string handler = Clean(statement.ColumnText(2));
                    NotificationItem item = ToastParser.Parse(payload, handler);
                    if (item != null)
                    {
                        item.CursorOrder = statement.ColumnInt64(0);
                        result.Add(item);
                    }
                }
            }

            return result;
        }

        private void EnsureOpen()
        {
            if (disposed)
            {
                throw new ObjectDisposedException("NotificationDatabase");
            }
            if (database != IntPtr.Zero)
            {
                return;
            }
            if (!File.Exists(databasePath))
            {
                throw new FileNotFoundException(
                    "找不到 Windows 通知数据库",
                    databasePath);
            }

            byte[] utf8Path = Encoding.UTF8.GetBytes(databasePath);
            int result = sqlite3_open_v2(
                utf8Path,
                out database,
                OpenReadOnly | OpenUri,
                IntPtr.Zero);
            if (result != SqliteOk)
            {
                if (database != IntPtr.Zero)
                {
                    sqlite3_close_v2(database);
                    database = IntPtr.Zero;
                }
                throw new InvalidOperationException(
                    "无法打开 Windows 通知数据库，错误码 " + result);
            }
            sqlite3_busy_timeout(database, BusyTimeoutMilliseconds);
        }

        private Statement Prepare(string sql)
        {
            EnsureOpen();
            IntPtr statement;
            IntPtr tail;
            byte[] utf8Sql = Encoding.UTF8.GetBytes(sql);
            int result = sqlite3_prepare_v2(
                database,
                utf8Sql,
                utf8Sql.Length,
                out statement,
                out tail);
            if (result != SqliteOk)
            {
                throw CreateError("准备通知查询失败");
            }
            return new Statement(this, statement);
        }

        private Exception CreateError(string prefix)
        {
            string detail = "";
            if (database != IntPtr.Zero)
            {
                IntPtr pointer = sqlite3_errmsg(database);
                if (pointer != IntPtr.Zero)
                {
                    detail = Marshal.PtrToStringAnsi(pointer);
                }
            }
            return new InvalidOperationException(
                prefix + (string.IsNullOrEmpty(detail) ? "" : "：" + detail));
        }

        private static string Clean(string value)
        {
            return value == null ? "" : value.Trim();
        }

        private void Close()
        {
            if (database != IntPtr.Zero)
            {
                sqlite3_close_v2(database);
                database = IntPtr.Zero;
            }
        }

        public void Dispose()
        {
            if (disposed)
            {
                return;
            }
            disposed = true;
            Close();
        }

        private sealed class Statement : IDisposable
        {
            private readonly NotificationDatabase owner;
            private IntPtr handle;

            public Statement(NotificationDatabase owner, IntPtr handle)
            {
                this.owner = owner;
                this.handle = handle;
            }

            public int Step()
            {
                return sqlite3_step(handle);
            }

            public void BindInt64(int index, long value)
            {
                int result = sqlite3_bind_int64(handle, index, value);
                if (result != SqliteOk)
                {
                    throw owner.CreateError("绑定通知游标失败");
                }
            }

            public long ColumnInt64(int index)
            {
                return sqlite3_column_int64(handle, index);
            }

            public string ColumnText(int index)
            {
                IntPtr pointer = sqlite3_column_text(handle, index);
                int length = sqlite3_column_bytes(handle, index);
                if (pointer == IntPtr.Zero || length <= 0)
                {
                    return "";
                }
                byte[] bytes = new byte[length];
                Marshal.Copy(pointer, bytes, 0, length);
                return Encoding.UTF8.GetString(bytes);
            }

            public byte[] ColumnBytes(int index)
            {
                IntPtr pointer = sqlite3_column_blob(handle, index);
                int length = sqlite3_column_bytes(handle, index);
                if (pointer == IntPtr.Zero || length <= 0)
                {
                    return new byte[0];
                }
                byte[] bytes = new byte[length];
                Marshal.Copy(pointer, bytes, 0, length);
                return bytes;
            }

            public void Dispose()
            {
                if (handle != IntPtr.Zero)
                {
                    sqlite3_finalize(handle);
                    handle = IntPtr.Zero;
                }
            }
        }

        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern int sqlite3_open_v2(
            byte[] filename,
            out IntPtr database,
            int flags,
            IntPtr virtualFileSystem);

        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern int sqlite3_close_v2(IntPtr database);

        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern int sqlite3_busy_timeout(
            IntPtr database,
            int milliseconds);

        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern int sqlite3_prepare_v2(
            IntPtr database,
            byte[] sql,
            int byteCount,
            out IntPtr statement,
            out IntPtr tail);

        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern int sqlite3_step(IntPtr statement);

        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern int sqlite3_bind_int64(
            IntPtr statement,
            int index,
            long value);

        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern long sqlite3_column_int64(
            IntPtr statement,
            int index);

        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr sqlite3_column_text(
            IntPtr statement,
            int index);

        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr sqlite3_column_blob(
            IntPtr statement,
            int index);

        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern int sqlite3_column_bytes(
            IntPtr statement,
            int index);

        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern int sqlite3_finalize(IntPtr statement);

        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr sqlite3_errmsg(IntPtr database);
    }

    internal static class ToastParser
    {
        public static NotificationItem Parse(byte[] payload, string handler)
        {
            if (payload == null || payload.Length == 0)
            {
                return null;
            }

            try
            {
                string xml = Decode(payload);
                XmlDocument document = new XmlDocument();
                document.XmlResolver = null;
                document.LoadXml(xml);

                List<string> texts = new List<string>();
                XmlNodeList nodes = document.SelectNodes(
                    "//*[local-name()='text']");
                if (nodes != null)
                {
                    for (int index = 0; index < nodes.Count; index++)
                    {
                        string text = Normalize(nodes[index].InnerText);
                        if (!string.IsNullOrEmpty(text))
                        {
                            texts.Add(text);
                        }
                    }
                }

                string title = texts.Count > 0
                    ? texts[0]
                    : Localization.Get("newNotification");
                string body = texts.Count > 1
                    ? texts[1]
                    : (texts.Count == 1
                        ? ""
                        : Localization.Get("newNotificationBody"));

                if (string.IsNullOrWhiteSpace(title))
                {
                    title = Localization.Get("newNotification");
                }

                NotificationItem item = new NotificationItem();
                item.AppName = FriendlyAppName(handler);
                item.Title = title.Trim();
                item.Body = body.Trim();
                item.ArrivedAt = DateTime.Now;
                return item;
            }
            catch (Exception exception)
            {
                Logger.Write("ToastParser: " + exception.Message);
                return null;
            }
        }

        private static string Decode(byte[] payload)
        {
            try
            {
                return new UTF8Encoding(false, true).GetString(payload);
            }
            catch (DecoderFallbackException)
            {
                return Encoding.Unicode.GetString(payload);
            }
        }

        private static string Normalize(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return "";
            }
            string cleaned = value.Replace("\r", " ").Replace("\n", " ");
            while (cleaned.Contains("  "))
            {
                cleaned = cleaned.Replace("  ", " ");
            }
            return cleaned.Trim();
        }

        private static string FriendlyAppName(string handler)
        {
            if (string.IsNullOrWhiteSpace(handler))
            {
                return Localization.Get("windows");
            }

            if (handler.IndexOf("OpenAI.Codex", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Codex";
            }
            if (handler.Equals("QQ", StringComparison.OrdinalIgnoreCase))
            {
                return "QQ";
            }
            if (handler.IndexOf("YourPhone", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "手机连接";
            }
            if (handler.IndexOf("DeepSeek", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "DeepSeek";
            }
            if (handler.IndexOf("Alarm", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "时钟";
            }
            if (handler.IndexOf("ScreenSketch", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "截图工具";
            }
            if (handler.IndexOf("WindowsStore", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Microsoft Store";
            }
            if (handler.IndexOf("alimail", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "阿里邮箱";
            }
            if (handler.IndexOf("WXWork", StringComparison.OrdinalIgnoreCase) >= 0 ||
                handler.IndexOf("WeChat", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "微信";
            }
            if (handler.IndexOf("SystemToast", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return Localization.Get("windows");
            }

            string name = handler;
            int bang = name.IndexOf('!');
            if (bang > 0)
            {
                name = name.Substring(0, bang);
            }
            int publisher = name.IndexOf("_8weky", StringComparison.OrdinalIgnoreCase);
            if (publisher > 0)
            {
                name = name.Substring(0, publisher);
            }
            int slash = name.LastIndexOfAny(new char[] { '\\', '/' });
            if (slash >= 0 && slash + 1 < name.Length)
            {
                name = name.Substring(slash + 1);
            }
            return string.IsNullOrWhiteSpace(name)
                ? Localization.Get("appNotification")
                : name;
        }
    }

    internal sealed class IslandApplication : ApplicationContext
    {
        private readonly BannerMuter bannerMuter;
        private readonly bool muteBanners;
        private readonly NotifyIcon notifyIcon;
        private readonly ContextMenuStrip menu;
        private readonly IslandForm island;
        private readonly NotificationMonitor monitor;
        private readonly MediaMonitor mediaMonitor;
        private readonly GlobalHotkeys hotkeys;
        private readonly ConsoleForm console;
        private readonly EventWaitHandle showConsoleEvent;
        private readonly RegisteredWaitHandle showConsoleWait;
        private readonly ToolStripMenuItem consoleItem;
        private readonly ToolStripMenuItem showItem;
        private readonly ToolStripMenuItem demoItem;
        private readonly ToolStripMenuItem pauseItem;
        private readonly ToolStripMenuItem historyItem;
        private readonly ToolStripMenuItem filtersItem;
        private readonly ToolStripMenuItem supportItem;
        private readonly ToolStripMenuItem musicModeItem;
        private readonly ToolStripMenuItem musicPersistentItem;
        private readonly ToolStripMenuItem exitItem;
        private readonly Icon generatedIcon;
        private readonly System.Windows.Forms.Timer bannerRefreshTimer;
        private readonly System.Windows.Forms.Timer settingsSaveTimer;
        private readonly System.Windows.Forms.Timer healthTimer;
        private readonly System.Windows.Forms.Timer timerTicker;
        private readonly string settingsPath;
        private readonly string historyPath;
        private readonly FullscreenDetector fullscreenDetector;
        private readonly List<NotificationHistoryEntry> notificationHistory =
            new List<NotificationHistoryEntry>();
        private readonly HashSet<string> filteredApps =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly SmartTimerSession timerSession =
            new SmartTimerSession();
        private readonly List<TimerPreset> timerPresets =
            new List<TimerPreset>();
        private readonly bool showConsole;
        private bool paused;
        private bool musicMode;
        private bool musicPersistent;
        private bool transparentWindow;
        private bool qualityEnhancement;
        private bool frostedGlassEnabled;
        private double uiScale = 1.0;
        private int maximumFrameRate = 120;
        private Color timerAccentColor = Color.FromArgb(100, 181, 246);
        private string timerSoundPath = "";
        private bool timerCompletionSoundPlayed;
        private SoundPlayer timerSoundPlayer;
        private double consoleOpacity = 0.5;
        private double frostedIntensity = 0.55;
        private bool autoStart;
        private bool movementEnabled;
        private bool clickThroughEnabled;
        private string dockEdge = "top";
        private int dockPosition = 1;
        private string dockScreen = "";
        private DateTime installedAt = DateTime.Today;
        private string screenSignature = "";
        private bool displaySuppressed;
        private bool safeMode;
        private int volumeHealthCounter;
        private DateTime startedAt = DateTime.UtcNow;
        private bool cleanedUp;

        public IslandApplication(
            BannerMuter bannerMuter,
            bool muteBanners,
            bool showConsole)
        {
            this.bannerMuter = bannerMuter;
            this.muteBanners = muteBanners;
            this.showConsole = showConsole;
            showConsoleEvent = new EventWaitHandle(
                false,
                EventResetMode.AutoReset,
                "Local\\SmartWindow.ShowConsole");
            settingsPath = Path.Combine(
                Environment.GetFolderPath(
                    Environment.SpecialFolder.LocalApplicationData),
                "SmartWindow",
                "settings.ini");
            historyPath = Path.Combine(
                Path.GetDirectoryName(settingsPath),
                "notification-history.dat");
            fullscreenDetector = new FullscreenDetector();
            LoadNotificationHistory();
            LoadFilteredApps();
            installedAt = ReadInstallDate();
            timerAccentColor = ReadTimerColor();
            timerSession.SetAccentColor(timerAccentColor);
            LoadTimerPresets();
            timerSoundPath = ReadStringSetting("timerSoundPath");
            Localization.SetLanguage(ReadLanguage());
            transparentWindow = ReadTransparentWindow();
            qualityEnhancement =
                transparentWindow && ReadBooleanSetting("qualityEnhancement");
            frostedGlassEnabled =
                transparentWindow && ReadBooleanSetting("frostedGlass");
            frostedIntensity = ReadFrostedIntensity();
            movementEnabled = ReadBooleanSetting("windowMovement");
            clickThroughEnabled = ReadBooleanSetting("clickThrough");
            safeMode = CrashGuard.IsSafeMode();
            if (safeMode)
            {
                transparentWindow = false;
                qualityEnhancement = false;
                frostedGlassEnabled = false;
                movementEnabled = false;
                clickThroughEnabled = false;
            }
            if (clickThroughEnabled)
            {
                movementEnabled = false;
            }
            dockEdge = ReadDockEdge();
            dockPosition = ReadDockPosition();
            dockScreen = ReadStringSetting("dockScreen");
            consoleOpacity = ReadConsoleOpacity();
            autoStart = AutoStartManager.IsEnabled();
            AutoStartManager.RefreshCommandIfEnabled();

            settingsSaveTimer = new System.Windows.Forms.Timer();
            settingsSaveTimer.Interval = 220;
            settingsSaveTimer.Tick += delegate
            {
                settingsSaveTimer.Stop();
                SaveSettings();
            };

            menu = new ContextMenuStrip();
            menu.ShowImageMargin = false;
            menu.Font = new Font(
                Localization.PreferredFontFamily,
                9f);
            consoleItem = new ToolStripMenuItem(
                Localization.Get("openConsole"));
            showItem = new ToolStripMenuItem(
                Localization.Get("showWindow"));
            demoItem = new ToolStripMenuItem(
                Localization.Get("demoNotification"));
            musicModeItem = new ToolStripMenuItem(
                Localization.Get("musicMode"));
            musicModeItem.CheckOnClick = true;
            musicPersistentItem = new ToolStripMenuItem(
                Localization.Get("musicPersistent"));
            musicPersistentItem.CheckOnClick = true;
            pauseItem = new ToolStripMenuItem(
                Localization.Get("pauseReceive"));
            historyItem = new ToolStripMenuItem(
                Localization.Get("notificationHistory"));
            filtersItem = new ToolStripMenuItem(
                Localization.Get("appFilters"));
            supportItem = new ToolStripMenuItem(
                Localization.Get("sponsorCoffeeButton"));
            exitItem = new ToolStripMenuItem(
                Localization.Get("exitRestore"));

            showItem.Click += delegate
            {
                island.Show();
                island.Demonstrate();
            };
            consoleItem.Click += delegate { ShowConsole(); };
            demoItem.Click += delegate { island.Demonstrate(); };
            musicModeItem.Click += delegate { SetMusicMode(musicModeItem.Checked); };
            musicPersistentItem.Click += delegate
            {
                SetMusicPersistent(musicPersistentItem.Checked);
            };
            pauseItem.Click += delegate { TogglePause(); };
            historyItem.Click += delegate
            {
                OpenNotificationManagement(true);
            };
            filtersItem.Click += delegate
            {
                OpenNotificationManagement(false);
            };
            supportItem.Click += delegate
            {
                OpenDonatePage();
            };
            exitItem.Click += delegate { ExitThread(); };
            menu.Items.Add(consoleItem);
            menu.Items.Add(showItem);
            menu.Items.Add(demoItem);
            menu.Items.Add(musicModeItem);
            menu.Items.Add(musicPersistentItem);
            menu.Items.Add(pauseItem);
            menu.Items.Add(historyItem);
            menu.Items.Add(filtersItem);
            menu.Items.Add(supportItem);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(exitItem);

            generatedIcon = CreateTrayIcon();
            notifyIcon = new NotifyIcon();
            notifyIcon.Icon = generatedIcon;
            notifyIcon.Text = FitTrayText(
                Localization.Get("appName") +
                " • " +
                Localization.Get(
                    muteBanners
                        ? "statusRunning"
                        : "demoBody"));
            notifyIcon.ContextMenuStrip = menu;
            notifyIcon.Visible = true;
            notifyIcon.DoubleClick += delegate { ShowConsole(); };

            island = new IslandForm();
            island.MediaCommandRequested += delegate(
                object sender,
                MediaCommandAction action)
            {
                mediaMonitor.SendCommand(action);
            };
            island.VolumeChangeRequested += delegate(
                object sender,
                double value)
            {
                SystemVolume.Set(value);
                island.SetVolume(SystemVolume.Get());
            };
            island.SeekRequested += delegate(
                object sender,
                double seconds)
            {
                mediaMonitor.SendSeek(seconds);
            };
            island.SoundSettingsRequested += delegate
            {
                try
                {
                    System.Diagnostics.Process.Start(
                        "ms-settings:sound");
                }
                catch (Exception exception)
                {
                    Logger.Write("Open sound settings: " + exception);
                }
            };
            island.MediaSourceOpenRequested += delegate
            {
                string appId = mediaMonitor.CurrentAppId;
                try
                {
                    if (!string.IsNullOrWhiteSpace(appId))
                    {
                        System.Diagnostics.Process.Start(
                            "explorer.exe",
                            "shell:AppsFolder\\" + appId);
                    }
                }
                catch (Exception exception)
                {
                    Logger.Write("Open media source: " + exception);
                }
            };
            island.MusicWindowCloseRequested += delegate
            {
                if (musicMode)
                {
                    SetMusicMode(false);
                }
            };
            island.TimerPauseToggleRequested += delegate(
                object sender,
                SmartTimerMode mode)
            {
                timerSession.TogglePause(mode);
                PublishTimerState();
            };
            island.TimerCancelRequested += delegate(
                object sender,
                SmartTimerMode mode)
            {
                timerSession.Cancel(mode);
                if (mode == SmartTimerMode.Countdown)
                {
                    StopTimerAlert();
                    timerCompletionSoundPlayed = false;
                }
                PublishTimerState();
            };
            island.TimerLapRequested += delegate(
                object sender,
                SmartTimerMode mode)
            {
                timerSession.AddLap(mode);
                PublishTimerState();
            };
            uiScale = ReadUiScale();
            maximumFrameRate = ReadMaximumFrameRate();
            island.SetUiScale(uiScale);
            island.SetFrameRateLimit(maximumFrameRate);
            island.SetGlassMode(transparentWindow);
            island.SetQualityEnhancement(qualityEnhancement);
            island.SetFrostedGlass(
                frostedGlassEnabled && transparentWindow,
                frostedIntensity);
            island.SetVolume(SystemVolume.Get());
            island.SetMovementEnabled(movementEnabled);
            island.SetClickThrough(clickThroughEnabled);
            island.SetDockEdge(dockEdge);
            island.SetDockPosition(dockPosition);
            island.SetDockScreen(dockScreen);
            island.DockEdgeChanged += delegate
            {
                dockEdge = island.DockEdgeName;
                dockPosition = island.DockPosition;
                dockScreen = island.DockScreenName;
                SaveSettings();
            };
            island.Show();
            island.DemonstrateStartup(muteBanners);

            monitor = new NotificationMonitor();
            monitor.NotificationReceived += OnNotificationReceived;
            monitor.StatusChanged += OnMonitorStatusChanged;
            monitor.Start();

            mediaMonitor = new MediaMonitor();
            mediaMonitor.StateChanged += OnMediaStateChanged;
            musicMode = ReadMusicMode();
            musicPersistent = ReadMusicPersistent();
            musicModeItem.Checked = musicMode;
            musicPersistentItem.Checked = musicPersistent;
            island.SetMusicMode(musicMode);
            island.SetMusicPinned(musicPersistent);
            if (musicMode)
            {
                mediaMonitor.Start();
            }
            hotkeys = new GlobalHotkeys(
                delegate { SetMusicMode(!musicMode); },
                delegate { SetMusicPersistent(!musicPersistent); },
                delegate { OpenNotificationManagement(true); });

            console = new ConsoleForm();
            console.SetPerformanceProvider(delegate
            {
                return island.GetPerformanceSnapshot();
            });
            console.PauseToggleRequested += delegate { TogglePause(); };
            console.MusicToggleRequested += delegate
            {
                SetMusicMode(!musicMode);
            };
            console.PersistentToggleRequested += delegate
            {
                SetMusicPersistent(!musicPersistent);
            };
            console.TestNotificationRequested += delegate
            {
                island.Demonstrate();
            };
            console.NotificationHistoryRequested += delegate
            {
                OpenNotificationManagement(true);
            };
            console.AppFiltersRequested += delegate
            {
                OpenNotificationManagement(false);
            };
            console.ExportSettingsRequested += delegate
            {
                ExportSettings();
            };
            console.ImportSettingsRequested += delegate
            {
                ImportSettings();
            };
            console.ResetSettingsRequested += delegate
            {
                ResetSettings();
            };
            console.SponsorRequested += delegate
            {
                OpenDonatePage();
            };
            console.SettingsRequested += delegate
            {
                try
                {
                    System.Diagnostics.Process.Start(
                        "ms-settings:notifications");
                }
                catch (Exception exception)
                {
                    Logger.Write(
                        "Open notification settings: " + exception);
                }
            };
            console.ExitRequested += delegate { ExitThread(); };
            console.GlassModeToggleRequested += delegate
            {
                transparentWindow = !transparentWindow;
                if (!transparentWindow)
                {
                    qualityEnhancement = false;
                    frostedGlassEnabled = false;
                }
                island.SetGlassMode(transparentWindow);
                island.SetQualityEnhancement(qualityEnhancement);
                island.SetFrostedGlass(
                    frostedGlassEnabled && transparentWindow,
                    frostedIntensity);
                SaveSettings();
                RefreshConsoleState();
            };
            console.QualityEnhanceToggleRequested += delegate
            {
                if (!transparentWindow)
                {
                    return;
                }
                qualityEnhancement = !qualityEnhancement;
                island.SetQualityEnhancement(qualityEnhancement);
                SaveSettings();
                RefreshConsoleState();
            };
            console.FrostedGlassToggleRequested += delegate
            {
                if (!transparentWindow)
                {
                    return;
                }
                frostedGlassEnabled = !frostedGlassEnabled;
                island.SetFrostedGlass(
                    frostedGlassEnabled,
                    frostedIntensity);
                SaveSettings();
                RefreshConsoleState();
            };
            console.AutoStartToggleRequested += delegate
            {
                bool enabled = !autoStart;
                if (AutoStartManager.SetEnabled(enabled))
                {
                    autoStart = enabled;
                    RefreshConsoleState();
                }
            };
            console.WindowMovementToggleRequested += delegate
            {
                bool enabled = !movementEnabled;
                if (enabled && clickThroughEnabled)
                {
                    clickThroughEnabled = false;
                    island.SetClickThrough(false);
                }
                movementEnabled = enabled;
                island.SetMovementEnabled(movementEnabled);
                SaveSettings();
                RefreshConsoleState();
            };
            console.ClickThroughToggleRequested += delegate
            {
                bool enabled = !clickThroughEnabled;
                if (enabled && movementEnabled)
                {
                    movementEnabled = false;
                    island.SetMovementEnabled(false);
                }
                clickThroughEnabled = enabled;
                island.SetClickThrough(clickThroughEnabled);
                SaveSettings();
                RefreshConsoleState();
            };
            console.ConsoleOpacityChanged += delegate(
                object sender,
                double opacity)
            {
                consoleOpacity = Math.Max(0.0, Math.Min(1.0, opacity));
                ScheduleSaveSettings();
            };
            console.FrostedIntensityChanged += delegate(
                object sender,
                double intensity)
            {
                frostedIntensity = Math.Max(
                    0.0,
                    Math.Min(1.0, intensity));
                island.SetFrostedGlass(
                    frostedGlassEnabled && transparentWindow,
                    frostedIntensity);
                ScheduleSaveSettings();
            };
            console.FrameRateLimitChanged += delegate(
                object sender,
                int frameRate)
            {
                maximumFrameRate = Math.Max(
                    60,
                    Math.Min(165, frameRate));
                island.SetFrameRateLimit(maximumFrameRate);
                SaveSettings();
                RefreshConsoleState();
            };
            console.TimerStartRequested += delegate(
                object sender,
                TimerStartRequest request)
            {
                if (request == null)
                {
                    return;
                }
                timerCompletionSoundPlayed = false;
                StopTimerAlert();
                timerSession.SetAccentColor(timerAccentColor);
                if (request.Mode == SmartTimerMode.Stopwatch)
                {
                    timerSession.StartStopwatch();
                }
                else
                {
                    timerSession.StartCountdown(request.Duration);
                }
                PublishTimerState();
            };
            console.TimerPauseToggleRequested += delegate(
                object sender,
                SmartTimerMode mode)
            {
                timerSession.TogglePause(mode);
                PublishTimerState();
            };
            console.TimerCancelRequested += delegate(
                object sender,
                SmartTimerMode mode)
            {
                timerSession.Cancel(mode);
                if (mode == SmartTimerMode.Countdown)
                {
                    StopTimerAlert();
                    timerCompletionSoundPlayed = false;
                }
                PublishTimerState();
            };
            console.TimerLapRequested += delegate(
                object sender,
                SmartTimerMode mode)
            {
                timerSession.AddLap(mode);
                PublishTimerState();
            };
            console.TimerColorChanged += delegate(
                object sender,
                Color color)
            {
                timerAccentColor = Color.FromArgb(255, color);
                timerSession.SetAccentColor(timerAccentColor);
                ScheduleSaveSettings();
                PublishTimerState();
            };
            console.TimerPresetAddRequested += delegate(
                object sender,
                TimerPreset preset)
            {
                if (preset == null || timerPresets.Count >= 6)
                {
                    return;
                }
                timerPresets.Add(preset);
                SaveSettings();
                PublishTimerState();
            };
            console.TimerPresetDeleteRequested += delegate(
                object sender,
                int index)
            {
                if (index >= 0 && index < timerPresets.Count)
                {
                    timerPresets.RemoveAt(index);
                    SaveSettings();
                    PublishTimerState();
                }
            };
            console.TimerSoundBrowseRequested += delegate
            {
                BrowseTimerSound();
            };
            console.TimerSoundPreviewRequested += delegate
            {
                PlayTimerAlert();
            };
            console.TimerSoundResetRequested += delegate
            {
                timerSoundPath = "";
                SaveSettings();
                PublishTimerState();
            };
            console.SizeScaleChanged += delegate(
                object sender,
                double scale)
            {
                uiScale = Math.Max(0.80, Math.Min(1.20, scale));
                island.SetUiScale(uiScale);
                island.ShowScalePreview(uiScale);
                ScheduleSaveSettings();
                RefreshConsoleState();
            };
            console.LanguageChangeRequested += delegate(
                object sender,
                UiLanguage language)
            {
                Localization.SetLanguage(language);
                SaveSettings();
                RefreshLocalizedText();
                island.RefreshLanguage();
                RefreshConsoleState();
                console.RefreshLocalization();
            };
            timerTicker = new System.Windows.Forms.Timer();
            timerTicker.Interval = 100;
            timerTicker.Tick += delegate
            {
                timerSession.Tick();
                PublishTimerState();
                if (timerSession.IsCompleted &&
                    !timerCompletionSoundPlayed)
                {
                    timerCompletionSoundPlayed = true;
                    PlayTimerAlert();
                }
            };
            timerTicker.Start();
            RefreshConsoleState(
                safeMode
                    ? Localization.Get("safeModeActive")
                    : null);
            if (showConsole)
            {
                console.ShowConsole();
            }
            showConsoleWait = ThreadPool.RegisterWaitForSingleObject(
                showConsoleEvent,
                delegate
                {
                    if (!island.IsDisposed)
                    {
                        island.BeginInvoke(new Action(ShowConsole));
                    }
                },
                null,
                Timeout.Infinite,
                false);

            bannerRefreshTimer = new System.Windows.Forms.Timer();
            bannerRefreshTimer.Interval = 3500;
            bannerRefreshTimer.Tick += delegate
            {
                if (muteBanners)
                {
                    ThreadPool.QueueUserWorkItem(delegate
                    {
                        bannerMuter.MuteCurrentApps();
                    });
                }
            };
            bannerRefreshTimer.Start();

            screenSignature = BuildScreenSignature();
            healthTimer = new System.Windows.Forms.Timer();
            healthTimer.Interval = 900;
            healthTimer.Tick += delegate
            {
                CheckRuntimeHealth();
            };
            healthTimer.Start();
            SaveSettings();
        }

        private void CheckRuntimeHealth()
        {
            string nextScreen = BuildScreenSignature();
            if (!string.Equals(
                nextScreen,
                screenSignature,
                StringComparison.Ordinal))
            {
                screenSignature = nextScreen;
                island.ReapplyGeometry();
            }

            bool suppressed = fullscreenDetector.IsSuppressed();
            if (suppressed != displaySuppressed)
            {
                displaySuppressed = suppressed;
                if (suppressed)
                {
                    island.DismissNotificationForPolicy();
                }
                RefreshConsoleState(
                    suppressed
                        ? Localization.Get("fullscreenSuppressed")
                        : null);
            }

            if (musicMode && !mediaMonitor.IsRunning)
            {
                mediaMonitor.Start();
            }
            volumeHealthCounter++;
            if (musicMode && volumeHealthCounter % 5 == 0)
            {
                island.SetVolume(SystemVolume.Get());
            }
            if ((DateTime.UtcNow - startedAt).TotalSeconds >= 45.0)
            {
                CrashGuard.MarkHealthy();
                safeMode = false;
            }
            island.EnsureAnimationClock();
        }

        private static string BuildScreenSignature()
        {
            Screen[] screens = Screen.AllScreens;
            StringBuilder builder = new StringBuilder();
            for (int index = 0; index < screens.Length; index++)
            {
                Rectangle bounds = screens[index].Bounds;
                Rectangle working = screens[index].WorkingArea;
                builder.Append(screens[index].DeviceName);
                builder.Append(',');
                builder.Append(bounds.Left);
                builder.Append(',');
                builder.Append(bounds.Top);
                builder.Append(',');
                builder.Append(bounds.Width);
                builder.Append(',');
                builder.Append(bounds.Height);
                builder.Append(',');
                builder.Append(working.Left);
                builder.Append(',');
                builder.Append(working.Top);
                builder.Append(',');
                builder.Append(working.Width);
                builder.Append(',');
                builder.Append(working.Height);
                builder.Append(';');
            }
            return builder.ToString();
        }

        private void OnNotificationReceived(object sender, NotificationItem item)
        {
            try
            {
                if (island.IsDisposed)
                {
                    return;
                }
                if (island.InvokeRequired)
                {
                    island.BeginInvoke(
                        new Action<object, NotificationItem>(
                            OnNotificationReceived),
                        new object[] { sender, item });
                    return;
                }
                bool filtered = IsAppFiltered(item.AppName);
                bool suppressedByDisplay = displaySuppressed;
                AddNotificationHistory(
                    item,
                    filtered,
                    suppressedByDisplay);
                if (!paused &&
                    !filtered &&
                    !suppressedByDisplay)
                {
                    island.Receive(item);
                }
            }
            catch (Exception exception)
            {
                Logger.Write("OnNotificationReceived: " + exception);
            }
        }

        private void OnMonitorStatusChanged(object sender, string status)
        {
            try
            {
                if (island.IsDisposed)
                {
                    return;
                }
                if (island.InvokeRequired)
                {
                    island.BeginInvoke(
                        new Action<object, string>(OnMonitorStatusChanged),
                        new object[] { sender, status });
                    return;
                }
                notifyIcon.Text = FitTrayText(status);
                RefreshConsoleState(status);
            }
            catch
            {
            }
        }

        private void TogglePause()
        {
            paused = !paused;
            pauseItem.Text = Localization.Get(
                paused ? "resumeReceive" : "pauseReceive");
            historyItem.Text =
                Localization.Get("notificationHistory");
            filtersItem.Text =
                Localization.Get("appFilters");
            supportItem.Text =
                Localization.Get("sponsorCoffeeButton");
            island.SetPaused(paused);
            RefreshConsoleState();
        }

        private void SetMusicMode(bool enabled)
        {
            musicMode = enabled;
            musicModeItem.Checked = enabled;
            SaveSettings();
            island.SetMusicMode(enabled);
            if (enabled)
            {
                mediaMonitor.Start();
            }
            else
            {
                mediaMonitor.Stop();
            }
            RefreshConsoleState();
        }

        private void SetMusicPersistent(bool enabled)
        {
            musicPersistent = enabled;
            musicPersistentItem.Checked = enabled;
            if (enabled && !musicMode)
            {
                SetMusicMode(true);
            }
            island.SetMusicPinned(enabled);
            SaveSettings();
            RefreshConsoleState();
        }

        private void ShowConsole()
        {
            if (console == null || console.IsDisposed)
            {
                return;
            }
            RefreshConsoleState();
            console.ShowConsole();
        }

        private void OpenNotificationManagement(bool showHistory)
        {
            using (NotificationManagementForm form =
                new NotificationManagementForm(
                    notificationHistory,
                    filteredApps,
                    showHistory))
            {
                form.ShowDialog(console);
                if (form.HistoryCleared)
                {
                    notificationHistory.Clear();
                    SaveNotificationHistory();
                }
                if (form.ResultFilters != null)
                {
                    filteredApps.Clear();
                    foreach (string appName in form.ResultFilters)
                    {
                        filteredApps.Add(appName);
                    }
                    SaveSettings();
                }
            }
        }

        private void OpenDonatePage()
        {
            if (!DonationIntegrityGuard.EnforceOrShutdown())
            {
                ExitThread();
                return;
            }
            try
            {
                System.Diagnostics.Process.Start(
                    DonationIntegrityGuard.Url);
            }
            catch (Exception exception)
            {
                Logger.Write("OpenDonatePage: " + exception);
            }
        }

        private void ExportSettings()
        {
            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Title = Localization.Get("exportSettings");
                dialog.Filter = "INI (*.ini)|*.ini|All files (*.*)|*.*";
                dialog.FileName = "SmartWindow-1.1.0-settings.ini";
                if (dialog.ShowDialog(console) != DialogResult.OK)
                {
                    return;
                }
                try
                {
                    SaveSettings();
                    File.Copy(settingsPath, dialog.FileName, true);
                }
                catch (Exception exception)
                {
                    Logger.Write("ExportSettings: " + exception);
                    MessageBox.Show(
                        exception.Message,
                        Localization.Get("exportSettings"),
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }

        private void ImportSettings()
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = Localization.Get("importSettings");
                dialog.Filter = "INI (*.ini)|*.ini|All files (*.*)|*.*";
                if (dialog.ShowDialog(console) != DialogResult.OK)
                {
                    return;
                }
                try
                {
                    string[] lines = File.ReadAllLines(
                        dialog.FileName,
                        Encoding.UTF8);
                    File.WriteAllLines(
                        settingsPath,
                        lines,
                        Encoding.UTF8);
                    ApplySettingsFromDisk();
                }
                catch (Exception exception)
                {
                    Logger.Write("ImportSettings: " + exception);
                    MessageBox.Show(
                        exception.Message,
                        Localization.Get("importSettings"),
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }

        private void ApplySettingsFromDisk()
        {
            Localization.SetLanguage(ReadLanguage());
            musicMode = ReadMusicMode();
            musicPersistent = ReadMusicPersistent();
            transparentWindow = ReadTransparentWindow();
            qualityEnhancement =
                transparentWindow &&
                ReadBooleanSetting("qualityEnhancement");
            frostedGlassEnabled =
                transparentWindow &&
                ReadBooleanSetting("frostedGlass");
            frostedIntensity = ReadFrostedIntensity();
            uiScale = ReadUiScale();
            maximumFrameRate = ReadMaximumFrameRate();
            consoleOpacity = ReadConsoleOpacity();
            timerAccentColor = ReadTimerColor();
            timerSession.SetAccentColor(timerAccentColor);
            LoadTimerPresets();
            timerSoundPath = ReadStringSetting("timerSoundPath");
            movementEnabled = ReadBooleanSetting("windowMovement");
            clickThroughEnabled = ReadBooleanSetting("clickThrough");
            if (clickThroughEnabled)
            {
                movementEnabled = false;
            }
            dockEdge = ReadDockEdge();
            dockPosition = ReadDockPosition();
            dockScreen = ReadStringSetting("dockScreen");
            installedAt = ReadInstallDate();
            LoadFilteredApps();
            musicModeItem.Checked = musicMode;
            musicPersistentItem.Checked = musicPersistent;
            island.SetUiScale(uiScale);
            island.SetFrameRateLimit(maximumFrameRate);
            PublishTimerState();
            island.SetGlassMode(transparentWindow);
            island.SetQualityEnhancement(qualityEnhancement);
            island.SetFrostedGlass(
                frostedGlassEnabled && transparentWindow,
                frostedIntensity);
            island.SetMovementEnabled(movementEnabled);
            island.SetClickThrough(clickThroughEnabled);
            island.SetDockEdge(dockEdge);
            island.SetDockPosition(dockPosition);
            island.SetDockScreen(dockScreen);
            island.SetMusicMode(musicMode);
            island.SetMusicPinned(musicPersistent);
            if (musicMode)
            {
                mediaMonitor.Start();
            }
            else
            {
                mediaMonitor.Stop();
            }
            RefreshLocalizedText();
            island.RefreshLanguage();
            console.RefreshLocalization();
            RefreshConsoleState();
        }

        private void ResetSettings()
        {
            if (MessageBox.Show(
                Localization.Get("resetConfirm"),
                Localization.Get("resetSettings"),
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning) != DialogResult.Yes)
            {
                return;
            }

            musicMode = false;
            musicPersistent = false;
            transparentWindow = false;
            qualityEnhancement = false;
            frostedGlassEnabled = false;
            movementEnabled = false;
            clickThroughEnabled = false;
            dockEdge = "top";
            dockPosition = 1;
            dockScreen = "";
            uiScale = 1.0;
            maximumFrameRate = 120;
            consoleOpacity = 0.5;
            timerAccentColor = Color.FromArgb(100, 181, 246);
            timerSoundPath = "";
            timerSession.CancelAll();
            StopTimerAlert();
            timerCompletionSoundPlayed = false;
            timerSession.SetAccentColor(timerAccentColor);
            timerPresets.Clear();
            AddDefaultTimerPresets();
            PublishTimerState();
            filteredApps.Clear();
            CrashGuard.MarkHealthy();
            safeMode = false;
            AutoStartManager.SetEnabled(false);
            autoStart = false;
            Localization.SetLanguage(UiLanguage.Chinese);
            musicModeItem.Checked = false;
            musicPersistentItem.Checked = false;
            island.SetUiScale(uiScale);
            island.SetFrameRateLimit(maximumFrameRate);
            island.SetGlassMode(false);
            island.SetQualityEnhancement(false);
            island.SetFrostedGlass(false, frostedIntensity);
            island.SetMovementEnabled(false);
            island.SetClickThrough(false);
            island.SetDockEdge(dockEdge);
            island.SetDockPosition(dockPosition);
            island.SetDockScreen(dockScreen);
            island.SetMusicMode(false);
            island.SetMusicPinned(false);
            mediaMonitor.Stop();
            SaveSettings();
            RefreshLocalizedText();
            island.RefreshLanguage();
            console.RefreshLocalization();
            RefreshConsoleState();
        }

        private void RefreshConsoleState(string status = null)
        {
            if (console == null || console.IsDisposed)
            {
                return;
            }
            console.SetState(
                paused,
                musicMode,
                musicPersistent,
                transparentWindow,
                qualityEnhancement,
                frostedGlassEnabled,
                frostedIntensity,
                autoStart,
                movementEnabled,
                clickThroughEnabled,
                status ??
                    Localization.Get(
                        paused ? "statusPaused" : "statusRunning"),
                uiScale,
                consoleOpacity,
                maximumFrameRate,
                installedAt);
        }

        private void PublishTimerState()
        {
            if (island == null || island.IsDisposed)
            {
                return;
            }
            TimerSnapshot snapshot = timerSession.CreateSnapshot(
                SmartTimerMode.Countdown);
            island.UpdateTimer(snapshot);
            if (console != null && !console.IsDisposed)
            {
                console.SetTimerState(
                    snapshot,
                    timerPresets.ToArray(),
                    timerSoundPath);
            }
        }

        private void BrowseTimerSound()
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = Localization.Get("timerChooseSound");
                dialog.Filter = "WAV (*.wav)|*.wav";
                dialog.CheckFileExists = true;
                if (dialog.ShowDialog(console) != DialogResult.OK)
                {
                    return;
                }
                timerSoundPath = dialog.FileName;
                SaveSettings();
                PublishTimerState();
            }
        }

        private void PlayTimerAlert()
        {
            try
            {
                string path = timerSoundPath;
                if (!string.IsNullOrWhiteSpace(path) &&
                    File.Exists(path))
                {
                    try
                    {
                        PlayTimerAlertFile(path);
                        return;
                    }
                    catch (Exception exception)
                    {
                        Logger.Write(
                            "Custom timer alert failed: " +
                            exception);
                    }
                }
                PlayTimerAlertFile(RuntimeAssets.TimerAlertPath);
            }
            catch (Exception exception)
            {
                Logger.Write("PlayTimerAlert: " + exception);
            }
        }

        private void PlayTimerAlertFile(string path)
        {
            if (!File.Exists(path))
            {
                return;
            }
            StopTimerAlert();
            timerSoundPlayer = new SoundPlayer(path);
            timerSoundPlayer.Load();
            timerSoundPlayer.Play();
        }

        private void StopTimerAlert()
        {
            SoundPlayer player = timerSoundPlayer;
            timerSoundPlayer = null;
            if (player == null)
            {
                return;
            }
            try
            {
                player.Stop();
            }
            catch (Exception exception)
            {
                Logger.Write("StopTimerAlert: " + exception);
            }
            finally
            {
                player.Dispose();
            }
        }

        private void RefreshLocalizedText()
        {
            Font previousFont = menu.Font;
            menu.Font = new Font(
                Localization.PreferredFontFamily,
                9f);
            if (previousFont != null)
            {
                previousFont.Dispose();
            }
            consoleItem.Text = Localization.Get("openConsole");
            showItem.Text = Localization.Get("showWindow");
            demoItem.Text = Localization.Get("demoNotification");
            musicModeItem.Text = Localization.Get("musicMode");
            musicPersistentItem.Text = Localization.Get("musicPersistent");
            pauseItem.Text = Localization.Get(
                paused ? "resumeReceive" : "pauseReceive");
            exitItem.Text = Localization.Get("exitRestore");
            notifyIcon.Text = FitTrayText(
                Localization.Get("appName") + " • " +
                Localization.Get(
                    paused ? "statusPaused" : "statusRunning"));
        }

        private static string FitTrayText(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return "Smart Window";
            }
            return value.Length > 63
                ? value.Substring(0, 63)
                : value;
        }

        private void OnMediaStateChanged(
            object sender,
            MediaPlaybackState state)
        {
            try
            {
                if (island.IsDisposed)
                {
                    return;
                }
                if (island.InvokeRequired)
                {
                    island.BeginInvoke(
                        new Action<object, MediaPlaybackState>(
                            OnMediaStateChanged),
                        new object[] { sender, state });
                    return;
                }
                island.UpdateMedia(state);
            }
            catch (Exception exception)
            {
                Logger.Write("OnMediaStateChanged: " + exception);
            }
        }

        private void AddNotificationHistory(
            NotificationItem item,
            bool filtered,
            bool suppressed)
        {
            notificationHistory.Insert(
                0,
                new NotificationHistoryEntry
                {
                    ReceivedAt = item.ArrivedAt == DateTime.MinValue
                        ? DateTime.Now
                        : item.ArrivedAt,
                    AppName = item.AppName ?? "",
                    Title = item.Title ?? "",
                    Body = item.Body ?? "",
                    WasFiltered = filtered,
                    WasSuppressed = suppressed
                });
            if (notificationHistory.Count > 100)
            {
                notificationHistory.RemoveRange(
                    100,
                    notificationHistory.Count - 100);
            }
            SaveNotificationHistory();
        }

        private bool IsAppFiltered(string appName)
        {
            return !string.IsNullOrWhiteSpace(appName) &&
                filteredApps.Contains(appName.Trim());
        }

        private void SaveNotificationHistory()
        {
            try
            {
                Directory.CreateDirectory(
                    Path.GetDirectoryName(historyPath));
                StringBuilder builder = new StringBuilder();
                for (int index = 0;
                    index < notificationHistory.Count;
                    index++)
                {
                    NotificationHistoryEntry item =
                        notificationHistory[index];
                    builder.Append(item.ReceivedAt.Ticks);
                    builder.Append('\t');
                    builder.Append(Convert.ToBase64String(
                        Encoding.UTF8.GetBytes(item.AppName ?? "")));
                    builder.Append('\t');
                    builder.Append(Convert.ToBase64String(
                        Encoding.UTF8.GetBytes(item.Title ?? "")));
                    builder.Append('\t');
                    builder.Append(Convert.ToBase64String(
                        Encoding.UTF8.GetBytes(item.Body ?? "")));
                    builder.Append('\t');
                    builder.Append(item.WasFiltered ? '1' : '0');
                    builder.Append('\t');
                    builder.Append(item.WasSuppressed ? '1' : '0');
                    builder.AppendLine();
                }
                File.WriteAllText(
                    historyPath,
                    builder.ToString(),
                    Encoding.UTF8);
            }
            catch (Exception exception)
            {
                Logger.Write("SaveNotificationHistory: " + exception);
            }
        }

        private void LoadNotificationHistory()
        {
            try
            {
                if (!File.Exists(historyPath))
                {
                    return;
                }
                string[] lines = File.ReadAllLines(
                    historyPath,
                    Encoding.UTF8);
                for (int index = 0;
                    index < lines.Length &&
                    notificationHistory.Count < 100;
                    index++)
                {
                    string[] parts = lines[index].Split('\t');
                    if (parts.Length < 6)
                    {
                        continue;
                    }
                    long ticks;
                    if (!long.TryParse(parts[0], out ticks))
                    {
                        continue;
                    }
                    notificationHistory.Add(
                        new NotificationHistoryEntry
                        {
                            ReceivedAt = new DateTime(ticks),
                            AppName = DecodeHistoryText(parts[1]),
                            Title = DecodeHistoryText(parts[2]),
                            Body = DecodeHistoryText(parts[3]),
                            WasFiltered = parts[4] == "1",
                            WasSuppressed = parts[5] == "1"
                        });
                }
            }
            catch (Exception exception)
            {
                Logger.Write("LoadNotificationHistory: " + exception);
            }
        }

        private static string DecodeHistoryText(string value)
        {
            try
            {
                return Encoding.UTF8.GetString(
                    Convert.FromBase64String(value));
            }
            catch
            {
                return "";
            }
        }

        private void LoadFilteredApps()
        {
            filteredApps.Clear();
            string encoded = ReadStringSetting("filteredApps");
            if (string.IsNullOrWhiteSpace(encoded))
            {
                return;
            }
            try
            {
                string[] values = Encoding.UTF8.GetString(
                    Convert.FromBase64String(encoded))
                    .Split('\n');
                for (int index = 0; index < values.Length; index++)
                {
                    string value = values[index].Trim();
                    if (value.Length > 0)
                    {
                        filteredApps.Add(value);
                    }
                }
            }
            catch (Exception exception)
            {
                Logger.Write("LoadFilteredApps: " + exception);
            }
        }

        private string EncodeFilteredApps()
        {
            return Convert.ToBase64String(
                Encoding.UTF8.GetBytes(
                    string.Join(
                        "\n",
                        new List<string>(filteredApps).ToArray())));
        }

        private bool ReadMusicMode()
        {
            try
            {
                if (!File.Exists(settingsPath))
                {
                    return false;
                }
                string[] lines = File.ReadAllLines(settingsPath, Encoding.UTF8);
                for (int index = 0; index < lines.Length; index++)
                {
                    if (string.Equals(
                        lines[index].Trim(),
                        "musicMode=1",
                        StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
            }
            catch (Exception exception)
            {
                Logger.Write("ReadMusicMode: " + exception);
            }
            return false;
        }

        private bool ReadMusicPersistent()
        {
            try
            {
                if (!File.Exists(settingsPath))
                {
                    return false;
                }
                string[] lines = File.ReadAllLines(settingsPath, Encoding.UTF8);
                for (int index = 0; index < lines.Length; index++)
                {
                    if (string.Equals(
                        lines[index].Trim(),
                        "musicPersistent=1",
                        StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
            }
            catch (Exception exception)
            {
                Logger.Write("ReadMusicPersistent: " + exception);
            }
            return false;
        }

        private UiLanguage ReadLanguage()
        {
            try
            {
                if (!File.Exists(settingsPath))
                {
                    return UiLanguage.Chinese;
                }
                string[] lines = File.ReadAllLines(settingsPath, Encoding.UTF8);
                for (int index = 0; index < lines.Length; index++)
                {
                    string line = lines[index].Trim();
                    if (line.StartsWith(
                        "language=",
                        StringComparison.OrdinalIgnoreCase))
                    {
                        return Localization.FromCode(
                            line.Substring("language=".Length));
                    }
                }
            }
            catch (Exception exception)
            {
                Logger.Write("ReadLanguage: " + exception);
            }
            return UiLanguage.Chinese;
        }

        private double ReadUiScale()
        {
            try
            {
                if (!File.Exists(settingsPath))
                {
                    return 1.0;
                }
                string[] lines = File.ReadAllLines(settingsPath, Encoding.UTF8);
                for (int index = 0; index < lines.Length; index++)
                {
                    string line = lines[index].Trim();
                    if (line.StartsWith(
                        "sizeScale=",
                        StringComparison.OrdinalIgnoreCase))
                    {
                        double value;
                        if (double.TryParse(
                            line.Substring("sizeScale=".Length),
                            System.Globalization.NumberStyles.Float,
                            System.Globalization.CultureInfo.InvariantCulture,
                            out value))
                        {
                            return Math.Max(0.80, Math.Min(1.20, value));
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Logger.Write("ReadUiScale: " + exception);
            }
            return 1.0;
        }

        private int ReadMaximumFrameRate()
        {
            try
            {
                if (!File.Exists(settingsPath))
                {
                    return 120;
                }
                string[] lines = File.ReadAllLines(settingsPath, Encoding.UTF8);
                for (int index = 0; index < lines.Length; index++)
                {
                    string line = lines[index].Trim();
                    if (line.StartsWith(
                        "maximumFrameRate=",
                        StringComparison.OrdinalIgnoreCase))
                    {
                        int value;
                        if (int.TryParse(
                            line.Substring("maximumFrameRate=".Length),
                            out value))
                        {
                            return Math.Max(60, Math.Min(165, value));
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Logger.Write("ReadMaximumFrameRate: " + exception);
            }
            return 120;
        }

        private Color ReadTimerColor()
        {
            string value = ReadStringSetting("timerColor");
            if (!string.IsNullOrWhiteSpace(value))
            {
                try
                {
                    return ColorTranslator.FromHtml(value);
                }
                catch
                {
                }
            }
            return Color.FromArgb(100, 181, 246);
        }

        private void LoadTimerPresets()
        {
            timerPresets.Clear();
            string value = ReadStringSetting("timerPresets");
            if (!string.IsNullOrWhiteSpace(value))
            {
                string[] parts = value.Split(';');
                for (int index = 0;
                    index < parts.Length && timerPresets.Count < 12;
                    index++)
                {
                    string part = parts[index];
                    int separator = part.LastIndexOf('|');
                    if (separator <= 0 ||
                        separator >= part.Length - 1)
                    {
                        continue;
                    }
                    int seconds;
                    if (!int.TryParse(
                        part.Substring(separator + 1),
                        out seconds) ||
                        seconds < 1)
                    {
                        continue;
                    }
                    string name;
                    try
                    {
                        name = Uri.UnescapeDataString(
                            part.Substring(0, separator));
                    }
                    catch
                    {
                        name = part.Substring(0, separator);
                    }
                    if (string.IsNullOrWhiteSpace(name))
                    {
                        continue;
                    }
                    timerPresets.Add(new TimerPreset(
                        name.Substring(0, Math.Min(32, name.Length)),
                        seconds));
                }
            }
            if (timerPresets.Count == 0)
            {
                AddDefaultTimerPresets();
            }
        }

        private void AddDefaultTimerPresets()
        {
            timerPresets.Add(new TimerPreset("专注 25 分钟", 25 * 60));
            timerPresets.Add(new TimerPreset("休息 5 分钟", 5 * 60));
            timerPresets.Add(new TimerPreset("快速 1 分钟", 60));
            timerPresets.Add(new TimerPreset("泡茶 3 分钟", 3 * 60));
        }

        private string EncodeTimerPresets()
        {
            List<string> encoded = new List<string>();
            for (int index = 0; index < timerPresets.Count; index++)
            {
                TimerPreset preset = timerPresets[index];
                encoded.Add(
                    Uri.EscapeDataString(preset.Name ?? "") +
                    "|" +
                    preset.DurationSeconds);
            }
            return string.Join(";", encoded.ToArray());
        }

        private bool ReadTransparentWindow()
        {
            try
            {
                if (!File.Exists(settingsPath))
                {
                    return false;
                }
                string[] lines = File.ReadAllLines(settingsPath, Encoding.UTF8);
                for (int index = 0; index < lines.Length; index++)
                {
                    if (string.Equals(
                        lines[index].Trim(),
                        "transparentWindow=1",
                        StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
            }
            catch (Exception exception)
            {
                Logger.Write("ReadTransparentWindow: " + exception);
            }
            return false;
        }

        private bool ReadBooleanSetting(string key)
        {
            try
            {
                if (!File.Exists(settingsPath))
                {
                    return false;
                }
                string expected = key + "=1";
                string[] lines = File.ReadAllLines(settingsPath, Encoding.UTF8);
                for (int index = 0; index < lines.Length; index++)
                {
                    if (string.Equals(
                        lines[index].Trim(),
                        expected,
                        StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
            }
            catch (Exception exception)
            {
                Logger.Write("ReadBooleanSetting: " + exception);
            }
            return false;
        }

        private string ReadStringSetting(string key)
        {
            try
            {
                if (!File.Exists(settingsPath))
                {
                    return "";
                }
                string prefix = key + "=";
                string[] lines = File.ReadAllLines(
                    settingsPath,
                    Encoding.UTF8);
                for (int index = 0; index < lines.Length; index++)
                {
                    string line = lines[index].Trim();
                    if (line.StartsWith(
                        prefix,
                        StringComparison.OrdinalIgnoreCase))
                    {
                        return line.Substring(prefix.Length);
                    }
                }
            }
            catch (Exception exception)
            {
                Logger.Write("ReadStringSetting: " + exception);
            }
            return "";
        }

        private string ReadDockEdge()
        {
            try
            {
                if (!File.Exists(settingsPath))
                {
                    return "top";
                }
                string[] lines = File.ReadAllLines(
                    settingsPath,
                    Encoding.UTF8);
                for (int index = 0; index < lines.Length; index++)
                {
                    string line = lines[index].Trim();
                    if (!line.StartsWith(
                        "dockEdge=",
                        StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }
                    string value = line.Substring("dockEdge=".Length);
                    if (string.Equals(
                            value,
                            "bottom",
                            StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(
                            value,
                            "left",
                            StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(
                            value,
                            "right",
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return value.ToLowerInvariant();
                    }
                    return "top";
                }
            }
            catch (Exception exception)
            {
                Logger.Write("ReadDockEdge: " + exception);
            }
            return "top";
        }

        private int ReadDockPosition()
        {
            try
            {
                if (!File.Exists(settingsPath))
                {
                    return 1;
                }
                string[] lines = File.ReadAllLines(
                    settingsPath,
                    Encoding.UTF8);
                for (int index = 0; index < lines.Length; index++)
                {
                    string line = lines[index].Trim();
                    if (!line.StartsWith(
                        "dockPosition=",
                        StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }
                    int value;
                    if (int.TryParse(
                        line.Substring("dockPosition=".Length),
                        out value))
                    {
                        return Math.Max(0, Math.Min(2, value));
                    }
                }
            }
            catch (Exception exception)
            {
                Logger.Write("ReadDockPosition: " + exception);
            }
            return 1;
        }

        private DateTime ReadInstallDate()
        {
            try
            {
                if (File.Exists(settingsPath))
                {
                    string[] lines = File.ReadAllLines(
                        settingsPath,
                        Encoding.UTF8);
                    for (int index = 0; index < lines.Length; index++)
                    {
                        string line = lines[index].Trim();
                        if (line.StartsWith(
                            "installDate=",
                            StringComparison.OrdinalIgnoreCase))
                        {
                            DateTime stored;
                            if (DateTime.TryParseExact(
                                line.Substring("installDate=".Length),
                                "yyyy-MM-dd",
                                System.Globalization.CultureInfo.InvariantCulture,
                                System.Globalization.DateTimeStyles.None,
                                out stored))
                            {
                                return stored.Date <= DateTime.Today
                                    ? stored.Date
                                    : DateTime.Today;
                            }
                        }
                    }

                    DateTime created = File
                        .GetCreationTimeUtc(settingsPath)
                        .ToLocalTime()
                        .Date;
                    if (created <= DateTime.Today)
                    {
                        return created;
                    }
                }
            }
            catch (Exception exception)
            {
                Logger.Write("ReadInstallDate: " + exception);
            }
            return DateTime.Today;
        }

        private double ReadConsoleOpacity()
        {
            try
            {
                if (!File.Exists(settingsPath))
                {
                    return 0.5;
                }
                string[] lines = File.ReadAllLines(settingsPath, Encoding.UTF8);
                for (int index = 0; index < lines.Length; index++)
                {
                    string line = lines[index].Trim();
                    if (line.StartsWith(
                        "consoleOpacity=",
                        StringComparison.OrdinalIgnoreCase))
                    {
                        double value;
                        if (double.TryParse(
                            line.Substring("consoleOpacity=".Length),
                            System.Globalization.NumberStyles.Float,
                            System.Globalization.CultureInfo.InvariantCulture,
                            out value))
                        {
                            return Math.Max(0.0, Math.Min(1.0, value));
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Logger.Write("ReadConsoleOpacity: " + exception);
            }
            return 0.5;
        }

        private double ReadFrostedIntensity()
        {
            try
            {
                if (!File.Exists(settingsPath))
                {
                    return 0.55;
                }
                string[] lines = File.ReadAllLines(settingsPath, Encoding.UTF8);
                for (int index = 0; index < lines.Length; index++)
                {
                    string line = lines[index].Trim();
                    if (line.StartsWith(
                        "frostedIntensity=",
                        StringComparison.OrdinalIgnoreCase))
                    {
                        double value;
                        if (double.TryParse(
                            line.Substring("frostedIntensity=".Length),
                            System.Globalization.NumberStyles.Float,
                            System.Globalization.CultureInfo.InvariantCulture,
                            out value))
                        {
                            return Math.Max(0.0, Math.Min(1.0, value));
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Logger.Write("ReadFrostedIntensity: " + exception);
            }
            return 0.55;
        }

        private void ScheduleSaveSettings()
        {
            settingsSaveTimer.Stop();
            settingsSaveTimer.Start();
        }

        private void SaveSettings()
        {
            try
            {
                string directory = Path.GetDirectoryName(settingsPath);
                Directory.CreateDirectory(directory);
                File.WriteAllText(
                    settingsPath,
                    "musicMode=" + (musicMode ? "1" : "0") +
                    Environment.NewLine +
                    "musicPersistent=" + (musicPersistent ? "1" : "0") +
                    Environment.NewLine +
                    "language=" + Localization.Code(Localization.Current) +
                    Environment.NewLine +
                    "sizeScale=" +
                    uiScale.ToString(
                        "0.###",
                        System.Globalization.CultureInfo.InvariantCulture) +
                    Environment.NewLine +
                    "maximumFrameRate=" +
                    maximumFrameRate +
                    Environment.NewLine +
                    "timerColor=#" +
                    timerAccentColor.R.ToString("X2") +
                    timerAccentColor.G.ToString("X2") +
                    timerAccentColor.B.ToString("X2") +
                    Environment.NewLine +
                    "timerSoundPath=" +
                    (timerSoundPath ?? "") +
                    Environment.NewLine +
                    "timerPresets=" +
                    EncodeTimerPresets() +
                    Environment.NewLine +
                    "transparentWindow=" +
                    (transparentWindow ? "1" : "0") +
                    Environment.NewLine +
                    "qualityEnhancement=" +
                    (qualityEnhancement ? "1" : "0") +
                    Environment.NewLine +
                    "frostedGlass=" +
                    (frostedGlassEnabled ? "1" : "0") +
                    Environment.NewLine +
                    "frostedIntensity=" +
                    frostedIntensity.ToString(
                        "0.###",
                        System.Globalization.CultureInfo.InvariantCulture) +
                    Environment.NewLine +
                    "windowMovement=" +
                    (movementEnabled ? "1" : "0") +
                    Environment.NewLine +
                    "clickThrough=" +
                    (clickThroughEnabled ? "1" : "0") +
                    Environment.NewLine +
                    "dockEdge=" +
                    dockEdge +
                    Environment.NewLine +
                    "dockPosition=" +
                    dockPosition +
                    Environment.NewLine +
                    "dockScreen=" +
                    (dockScreen ?? "") +
                    Environment.NewLine +
                    "installDate=" +
                    installedAt.ToString(
                        "yyyy-MM-dd",
                        System.Globalization.CultureInfo.InvariantCulture) +
                    Environment.NewLine +
                    "filteredApps=" +
                    EncodeFilteredApps() +
                    Environment.NewLine +
                    "consoleOpacity=" +
                    consoleOpacity.ToString(
                        "0.###",
                        System.Globalization.CultureInfo.InvariantCulture) +
                    Environment.NewLine,
                    Encoding.UTF8);
            }
            catch (Exception exception)
            {
                Logger.Write("SaveSettings: " + exception);
            }
        }

        protected override void ExitThreadCore()
        {
            if (cleanedUp)
            {
                base.ExitThreadCore();
                return;
            }
            cleanedUp = true;
            bannerRefreshTimer.Stop();
            bannerRefreshTimer.Dispose();
            healthTimer.Stop();
            healthTimer.Dispose();
            settingsSaveTimer.Stop();
            settingsSaveTimer.Dispose();
            if (timerTicker != null)
            {
                timerTicker.Stop();
                timerTicker.Dispose();
            }
            if (timerSoundPlayer != null)
            {
                StopTimerAlert();
            }
            monitor.Dispose();
            mediaMonitor.Dispose();
            hotkeys.Dispose();
            if (console != null && !console.IsDisposed)
            {
                console.CloseForExit();
                console.Dispose();
            }
            if (showConsoleWait != null)
            {
                showConsoleWait.Unregister(null);
            }
            showConsoleEvent.Dispose();
            notifyIcon.Visible = false;
            notifyIcon.Dispose();
            island.Close();
            island.Dispose();
            menu.Dispose();
            if (muteBanners)
            {
                bannerMuter.StopAndRestore();
            }
            generatedIcon.Dispose();
            base.ExitThreadCore();
        }

        private static Icon CreateTrayIcon()
        {
            Bitmap bitmap = new Bitmap(32, 32);
            using (Graphics graphics = Graphics.FromImage(bitmap))
            {
                graphics.SmoothingMode = SmoothingMode.AntiAlias;
                graphics.Clear(Color.Transparent);
                using (SolidBrush brush = new SolidBrush(Color.FromArgb(8, 8, 10)))
                {
                    graphics.FillEllipse(brush, 1, 1, 30, 30);
                }
                using (SolidBrush brush = new SolidBrush(Color.White))
                {
                    graphics.FillEllipse(brush, 10, 14, 4, 4);
                    graphics.FillEllipse(brush, 16, 12, 7, 7);
                    graphics.FillEllipse(brush, 25, 14, 4, 4);
                }
            }
            IntPtr handle = bitmap.GetHicon();
            bitmap.Dispose();
            try
            {
                using (Icon temporary = Icon.FromHandle(handle))
                {
                    return (Icon)temporary.Clone();
                }
            }
            finally
            {
                DestroyIcon(handle);
            }
        }

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool DestroyIcon(IntPtr handle);
    }

    internal sealed class NotificationMonitor : IDisposable
    {
        private readonly object databaseSync = new object();
        private NotificationDatabase database;
        private System.Threading.Timer timer;
        private long lastOrder;
        private int queryInProgress;
        private bool initialized;
        private bool disposed;

        public event EventHandler<NotificationItem> NotificationReceived;
        public event EventHandler<string> StatusChanged;

        public void Start()
        {
            timer = new System.Threading.Timer(
                Poll,
                null,
                0,
                450);
        }

        private void Poll(object state)
        {
            if (disposed ||
                Interlocked.CompareExchange(ref queryInProgress, 1, 0) != 0)
            {
                return;
            }

            try
            {
                lock (databaseSync)
                {
                    if (database == null)
                    {
                        database = new NotificationDatabase();
                    }

                    if (!initialized)
                    {
                        lastOrder = database.GetLatestOrder();
                        initialized = true;
                        RaiseStatus(Localization.Get("statusRunning"));
                        return;
                    }

                    List<NotificationItem> items =
                        database.GetNewNotifications(lastOrder);
                    if (items.Count > 0)
                    {
                        long newest = lastOrder;
                        for (int index = 0; index < items.Count; index++)
                        {
                            if (items[index].CursorOrder > newest)
                            {
                                newest = items[index].CursorOrder;
                            }
                        }
                        lastOrder = newest;

                        for (int index = 0; index < items.Count; index++)
                        {
                            EventHandler<NotificationItem> handler =
                                NotificationReceived;
                            if (handler != null)
                            {
                                handler(this, items[index]);
                            }
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                lock (databaseSync)
                {
                    if (database != null)
                    {
                        database.Dispose();
                        database = null;
                    }
                    initialized = false;
                }
                RaiseStatus(Localization.Get("statusRetry"));
                Logger.Write("Monitor: " + exception);
            }
            finally
            {
                Interlocked.Exchange(ref queryInProgress, 0);
            }
        }

        private void RaiseStatus(string status)
        {
            EventHandler<string> handler = StatusChanged;
            if (handler != null)
            {
                handler(this, status);
            }
        }

        public void Dispose()
        {
            if (disposed)
            {
                return;
            }
            disposed = true;
            if (timer != null)
            {
                timer.Dispose();
                timer = null;
            }
            lock (databaseSync)
            {
                if (database != null)
                {
                    database.Dispose();
                    database = null;
                }
            }
        }
    }

    internal sealed class LegacyIslandForm : Form
    {
        private const int CollapsedWidth = 154;
        private const int CollapsedHeight = 34;
        private const int ExpandedWidth = 510;
        private const int ExpandedHeight = 112;

        private readonly Queue<NotificationItem> queue =
            new Queue<NotificationItem>();

        private readonly System.Windows.Forms.Timer animationTimer;
        private readonly System.Windows.Forms.Timer displayTimer;
        private readonly System.Windows.Forms.Timer nextTimer;
        private readonly Font appFont;
        private readonly Font titleFont;
        private readonly Font bodyFont;
        private readonly Font tinyFont;

        private NotificationItem current;
        private int targetWidth = CollapsedWidth;
        private int targetHeight = CollapsedHeight;
        private int currentWidth = CollapsedWidth;
        private int currentHeight = CollapsedHeight;
        private int radius = 17;
        private bool hovering;
        private bool paused;

        public LegacyIslandForm()
        {
            Text = "智慧窗";
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            StartPosition = FormStartPosition.Manual;
            BackColor = Color.FromArgb(5, 5, 7);
            DoubleBuffered = true;
            AutoScaleMode = AutoScaleMode.None;
            Width = CollapsedWidth;
            Height = CollapsedHeight;
            Cursor = Cursors.Hand;

            string fontName = "Microsoft YaHei UI";
            appFont = new Font(fontName, 8.2f, FontStyle.Regular);
            titleFont = new Font(fontName, 9.4f, FontStyle.Bold);
            bodyFont = new Font(fontName, 9.7f, FontStyle.Regular);
            tinyFont = new Font(fontName, 7.8f, FontStyle.Regular);

            animationTimer = new System.Windows.Forms.Timer();
            animationTimer.Interval = 16;
            animationTimer.Tick += Animate;

            displayTimer = new System.Windows.Forms.Timer();
            displayTimer.Interval = 5700;
            displayTimer.Tick += DisplayTimeout;

            nextTimer = new System.Windows.Forms.Timer();
            nextTimer.Interval = 260;
            nextTimer.Tick += ShowNext;

            MouseEnter += delegate
            {
                hovering = true;
                Invalidate();
            };
            MouseLeave += delegate
            {
                hovering = false;
                Invalidate();
            };
            MouseClick += OnIslandClick;
        }

        protected override bool ShowWithoutActivation
        {
            get { return true; }
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams parameters = base.CreateParams;
                parameters.ExStyle |= 0x08000000; // WS_EX_NOACTIVATE
                parameters.ExStyle |= 0x00000080; // WS_EX_TOOLWINDOW
                return parameters;
            }
        }

        public void DemonstrateStartup(bool bannersMuted)
        {
            NotificationItem item = new NotificationItem();
            item.AppName = "智慧窗";
            item.Title = "已连接到屏幕顶部";
            item.Body = bannersMuted
                ? "右下角系统横幅已静默，通知会在这里展开"
                : "演示模式：系统横幅仍保持开启";
            Receive(item);
        }

        public void Demonstrate()
        {
            NotificationItem item = new NotificationItem();
            item.AppName = "智慧窗";
            item.Title = "这是一条演示通知";
            item.Body = "新消息会以胶囊形态出现，并自动展开、停留和收起";
            Receive(item);
        }

        public void SetPaused(bool value)
        {
            paused = value;
            if (paused)
            {
                current = null;
                queue.Clear();
                Collapse();
            }
            Invalidate();
        }

        public void Receive(NotificationItem item)
        {
            if (item == null || paused || IsDisposed)
            {
                return;
            }

            queue.Enqueue(item);
            if (current == null)
            {
                ShowNext(null, EventArgs.Empty);
            }
        }

        private void ShowNext(object sender, EventArgs e)
        {
            nextTimer.Stop();
            if (paused || queue.Count == 0)
            {
                Collapse();
                return;
            }

            current = queue.Dequeue();
            targetWidth = Scale(ExpandedWidth);
            targetHeight = Scale(ExpandedHeight);
            radius = Scale(27);
            animationTimer.Start();
            displayTimer.Stop();
            displayTimer.Start();
            Invalidate();
        }

        private void DisplayTimeout(object sender, EventArgs e)
        {
            displayTimer.Stop();
            if (hovering)
            {
                displayTimer.Start();
                return;
            }
            DismissCurrent();
        }

        private void DismissCurrent()
        {
            displayTimer.Stop();
            current = null;
            Collapse();
            if (queue.Count > 0)
            {
                nextTimer.Start();
            }
        }

        private void Collapse()
        {
            targetWidth = Scale(CollapsedWidth);
            targetHeight = Scale(CollapsedHeight);
            radius = Scale(17);
            animationTimer.Start();
            Invalidate();
        }

        private void Animate(object sender, EventArgs e)
        {
            int deltaWidth = targetWidth - currentWidth;
            int deltaHeight = targetHeight - currentHeight;
            if (Math.Abs(deltaWidth) <= 2 && Math.Abs(deltaHeight) <= 2)
            {
                currentWidth = targetWidth;
                currentHeight = targetHeight;
                animationTimer.Stop();
            }
            else
            {
                currentWidth += (int)Math.Round(deltaWidth * 0.24);
                currentHeight += (int)Math.Round(deltaHeight * 0.24);
            }
            ApplyGeometry();
        }

        private void ApplyGeometry()
        {
            Screen screen = Screen.PrimaryScreen;
            Rectangle bounds = screen.Bounds;
            int left = bounds.Left + (bounds.Width - currentWidth) / 2;
            int top = bounds.Top + Scale(8);
            SetBounds(left, top, currentWidth, currentHeight);

            using (GraphicsPath path = RoundedRectangle(
                new Rectangle(0, 0, currentWidth, currentHeight),
                Math.Min(radius, currentHeight / 2)))
            {
                Region oldRegion = Region;
                Region = new Region(path);
                if (oldRegion != null)
                {
                    oldRegion.Dispose();
                }
            }
            Invalidate();
        }

        private int Scale(int logicalPixels)
        {
            using (Graphics graphics = CreateGraphics())
            {
                return (int)Math.Round(
                    logicalPixels * graphics.DpiX / 96f);
            }
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            ApplyGeometry();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics graphics = e.Graphics;
            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            graphics.TextRenderingHint =
                System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            Rectangle outer = new Rectangle(
                0,
                0,
                ClientSize.Width - 1,
                ClientSize.Height - 1);
            using (GraphicsPath path = RoundedRectangle(
                outer,
                Math.Min(radius, ClientSize.Height / 2)))
            {
                using (LinearGradientBrush background =
                    new LinearGradientBrush(
                        outer,
                        Color.FromArgb(8, 8, 10),
                        Color.FromArgb(2, 2, 3),
                        LinearGradientMode.Vertical))
                {
                    graphics.FillPath(background, path);
                }
                using (Pen border = new Pen(Color.FromArgb(52, 255, 255, 255), 1f))
                {
                    graphics.DrawPath(border, path);
                }
            }

            if (current == null)
            {
                DrawIdle(graphics);
            }
            else
            {
                DrawExpanded(graphics);
            }
        }

        private void DrawIdle(Graphics graphics)
        {
            int centerX = ClientSize.Width / 2;
            int centerY = ClientSize.Height / 2;
            using (SolidBrush dim = new SolidBrush(Color.FromArgb(105, 255, 255, 255)))
            using (SolidBrush bright = new SolidBrush(Color.FromArgb(235, 255, 255, 255)))
            {
                graphics.FillEllipse(dim, centerX - Scale(18), centerY - Scale(2), Scale(4), Scale(4));
                graphics.FillEllipse(bright, centerX - Scale(5), centerY - Scale(2), Scale(5), Scale(5));
                graphics.FillEllipse(dim, centerX + Scale(10), centerY - Scale(2), Scale(4), Scale(4));
            }
        }

        private void DrawExpanded(Graphics graphics)
        {
            int padding = Scale(18);
            int avatarSize = Scale(38);
            int avatarTop = Scale(17);
            int textLeft = padding + avatarSize + Scale(14);
            int titleTop = Scale(15);
            int timeWidth = Scale(50);

            Color accent = AccentFor(current.AppName);
            Rectangle avatar = new Rectangle(padding, avatarTop, avatarSize, avatarSize);
            using (LinearGradientBrush avatarBrush =
                new LinearGradientBrush(
                    avatar,
                    Color.FromArgb(255, accent),
                    Color.FromArgb(185, accent),
                    45f))
            {
                graphics.FillEllipse(avatarBrush, avatar);
            }
            using (Pen highlight = new Pen(Color.FromArgb(55, 255, 255, 255), 1f))
            {
                graphics.DrawEllipse(highlight, avatar);
            }

            string monogram = Monogram(current.AppName);
            SizeF monogramSize = graphics.MeasureString(monogram, titleFont);
            using (SolidBrush white = new SolidBrush(Color.White))
            {
                graphics.DrawString(
                    monogram,
                    titleFont,
                    white,
                    avatar.Left + (avatar.Width - monogramSize.Width) / 2f,
                    avatar.Top + (avatar.Height - monogramSize.Height) / 2f);
            }

            int rightPadding = Scale(20);
            Rectangle appRect = new Rectangle(
                textLeft,
                titleTop,
                ClientSize.Width - textLeft - timeWidth - rightPadding,
                Scale(20));
            TextRenderer.DrawText(
                graphics,
                current.AppName.ToUpperInvariant(),
                tinyFont,
                appRect,
                Color.FromArgb(160, 255, 255, 255),
                TextFormatFlags.Left |
                TextFormatFlags.VerticalCenter |
                TextFormatFlags.NoPadding |
                TextFormatFlags.EndEllipsis);

            Rectangle titleRect = new Rectangle(
                textLeft,
                Scale(31),
                ClientSize.Width - textLeft - rightPadding,
                Scale(25));
            TextRenderer.DrawText(
                graphics,
                current.Title,
                titleFont,
                titleRect,
                Color.FromArgb(248, 255, 255, 255),
                TextFormatFlags.Left |
                TextFormatFlags.VerticalCenter |
                TextFormatFlags.NoPadding |
                TextFormatFlags.EndEllipsis);

            if (!string.IsNullOrWhiteSpace(current.Body))
            {
                Rectangle bodyRect = new Rectangle(
                    textLeft,
                    Scale(56),
                    ClientSize.Width - textLeft - padding,
                    Scale(38));
                TextRenderer.DrawText(
                    graphics,
                    current.Body,
                    bodyFont,
                    bodyRect,
                    Color.FromArgb(215, 235, 235, 240),
                    TextFormatFlags.Left |
                    TextFormatFlags.Top |
                    TextFormatFlags.NoPadding |
                    TextFormatFlags.WordBreak |
                    TextFormatFlags.EndEllipsis);
            }

            Rectangle timeRect = new Rectangle(
                ClientSize.Width - timeWidth - Scale(13),
                titleTop,
                timeWidth,
                Scale(18));
            TextRenderer.DrawText(
                graphics,
                hovering ? "×" : "刚刚",
                tinyFont,
                timeRect,
                Color.FromArgb(
                    hovering ? 210 : 105,
                    255,
                    255,
                    255),
                TextFormatFlags.Right |
                TextFormatFlags.VerticalCenter |
                TextFormatFlags.NoPadding);

            using (SolidBrush accentBrush = new SolidBrush(
                Color.FromArgb(185, accent)))
            {
                graphics.FillEllipse(
                    accentBrush,
                    ClientSize.Width - Scale(17),
                    Scale(54),
                    Scale(4),
                    Scale(4));
            }

            if (queue.Count > 0)
            {
                Rectangle queueRect = new Rectangle(
                    ClientSize.Width - Scale(44),
                    Scale(54),
                    Scale(25),
                    Scale(16));
                TextRenderer.DrawText(
                    graphics,
                    "+" + queue.Count.ToString(),
                    tinyFont,
                    queueRect,
                    Color.FromArgb(130, 255, 255, 255),
                    TextFormatFlags.Right |
                    TextFormatFlags.VerticalCenter |
                    TextFormatFlags.NoPadding);
            }
        }

        private void OnIslandClick(object sender, MouseEventArgs e)
        {
            if (current == null)
            {
                Demonstrate();
                return;
            }

            if (e.X > ClientSize.Width - Scale(54) &&
                e.Y < Scale(44))
            {
                DismissCurrent();
                return;
            }

            // A second click dismisses the current card; a third starts the
            // next queued notification without waiting for the full timeout.
            DismissCurrent();
        }

        private static Color AccentFor(string appName)
        {
            int hash = StringComparer.OrdinalIgnoreCase.GetHashCode(appName ?? "");
            int index = hash % 5;
            if (index < 0)
            {
                index = -index;
            }
            Color[] palette = new Color[]
            {
                Color.FromArgb(45, 150, 255),
                Color.FromArgb(90, 200, 150),
                Color.FromArgb(245, 145, 55),
                Color.FromArgb(175, 100, 245),
                Color.FromArgb(230, 75, 115)
            };
            return palette[index];
        }

        private static string Monogram(string appName)
        {
            if (string.IsNullOrWhiteSpace(appName))
            {
                return "•";
            }
            string trimmed = appName.Trim();
            if (trimmed.Length == 1)
            {
                return trimmed.ToUpperInvariant();
            }
            return trimmed.Substring(0, 1).ToUpperInvariant();
        }

        private static GraphicsPath RoundedRectangle(Rectangle bounds, int radius)
        {
            int diameter = Math.Max(1, radius * 2);
            GraphicsPath path = new GraphicsPath();
            Rectangle arc = new Rectangle(bounds.Location, new Size(diameter, diameter));

            path.AddArc(arc, 180, 90);
            arc.X = bounds.Right - diameter;
            path.AddArc(arc, 270, 90);
            arc.Y = bounds.Bottom - diameter;
            path.AddArc(arc, 0, 90);
            arc.X = bounds.Left;
            path.AddArc(arc, 90, 90);
            path.CloseFigure();
            return path;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                animationTimer.Dispose();
                displayTimer.Dispose();
                nextTimer.Dispose();
                appFont.Dispose();
                titleFont.Dispose();
                bodyFont.Dispose();
                tinyFont.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
